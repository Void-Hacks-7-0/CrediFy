
import { Language } from "../types";

export const translations = {
  en: {
    dashboard: "Dashboard",
    expenses: "Expenses",
    wallet: "Wallet",
    investments: "Investments",
    contracts: "Contracts",
    goals: "Goals",
    education: "Education",
    identity: "Identity",
    
    // Dashboard
    totalBalance: "Total Available Balance",
    budgetLeft: "Budget Left",
    financialHealth: "Financial Health",
    monthlySpend: "Monthly Spend",
    income: "Income",
    upcomingBills: "Upcoming Bills",
    riskAlerts: "Risk Alerts",
    spendingTrends: "Spending Trends vs Budget",
    expenseCat: "Expense Categorization",
    smartBill: "Smart Bill Alerts",
    payNow: "Pay Now",
    paid: "Paid",
    overdue: "Overdue",
    dueIn: "Due in",

    // Expenses
    addExpense: "Add Expense",
    amount: "Amount",
    category: "Category",
    description: "Description",
    addToChain: "Add to Blockchain + Earn Rewards",
    searchTx: "Search transactions...",
    exportCsv: "Export CSV",
    voiceInput: "Voice Entry (Beta)",
    listening: "Listening...",
    voiceTip: "Try saying: 'Spent 50 rupees on Food'",

    // Wallet
    totalLiquidity: "Total Liquidity",
    addMoney: "Add Money",
    available: "Available",
    locked: "Locked",
    rewards: "SecureCoin Rewards",
    redeem: "Redeem Tokens",
    transfer: "Zero-Fee Transfer",
    recipient: "Recipient ID / Mobile",
    sendSecurely: "Send Securely",
    liveLedger: "Live Ledger",
    quickContacts: "Quick Contacts",

    // Education
    aiTutor: "AI Finance Tutor",
    quiz: "Daily Finance Quiz",
    investmentBasics: "Investment Basics (India)",
    govtSchemes: "Govt Schemes",
  },
  hi: {
    dashboard: "डैशबोर्ड",
    expenses: "खर्चे (Expenses)",
    wallet: "वॉलेट (Wallet)",
    investments: "निवेश (Investments)",
    contracts: "अनुबंध (Contracts)",
    goals: "लक्ष्य (Goals)",
    education: "शिक्षा (Learn)",
    identity: "पहचान (ID)",

    // Dashboard
    totalBalance: "कुल उपलब्ध राशि",
    budgetLeft: "बचा हुआ बजट",
    financialHealth: "वित्तीय स्वास्थ्य",
    monthlySpend: "मासिक खर्च",
    income: "आमदनी",
    upcomingBills: "आगामी बिल",
    riskAlerts: "जोखिम अलर्ट",
    spendingTrends: "खर्च के रुझान",
    expenseCat: "खर्च श्रेणियाँ",
    smartBill: "बिल अलर्ट",
    payNow: "अभी भुगतान करें",
    paid: "भुगतान किया",
    overdue: "बकाया",
    dueIn: "दिन शेष",

    // Expenses
    addExpense: "नया खर्च जोड़ें",
    amount: "राशि",
    category: "श्रेणी",
    description: "विवरण",
    addToChain: "ब्लॉकचेन में जोड़ें + इनाम पाएं",
    searchTx: "लेनदेन खोजें...",
    exportCsv: "CSV डाउनलोड करें",
    voiceInput: "बोलकर लिखें",
    listening: "सुन रहा हूँ...",
    voiceTip: "कोशिश करें: 'खाने पर 50 रुपये खर्च किए'",

    // Wallet
    totalLiquidity: "कुल नकदी",
    addMoney: "पैसे डालें",
    available: "उपलब्ध",
    locked: "लॉक किया हुआ",
    rewards: "सिक्का इनाम",
    redeem: "टोकन भुनाएं",
    transfer: "शून्य-शुल्क ट्रांसफर",
    recipient: "प्राप्तकर्ता ID / मोबाइल",
    sendSecurely: "सुरक्षित भेजें",
    liveLedger: "लाइव लेजर",
    quickContacts: "त्वरित संपर्क",

    // Education
    aiTutor: "AI वित्तीय गुरु",
    quiz: "दैनिक प्रश्नोत्तरी",
    investmentBasics: "निवेश की मूल बातें",
    govtSchemes: "सरकारी योजनाएं",
  }
};

export const t = (lang: Language, key: keyof typeof translations['en']) => {
  return translations[lang][key] || translations['en'][key];
};
