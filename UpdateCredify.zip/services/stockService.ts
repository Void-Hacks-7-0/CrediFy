import { Stock } from '../types';

// Mock Indian Stock Data
const MOCK_STOCKS: Stock[] = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', price: 2450.50, change: 1.2, isUp: true },
  { symbol: 'TCS', name: 'Tata Consultancy Svcs', price: 3400.00, change: -0.5, isUp: false },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', price: 1650.75, change: 0.8, isUp: true },
  { symbol: 'INFY', name: 'Infosys Ltd', price: 1420.20, change: -1.1, isUp: false },
  { symbol: 'ICICIBANK', name: 'ICICI Bank', price: 950.00, change: 2.3, isUp: true },
  { symbol: 'SBIN', name: 'State Bank of India', price: 580.40, change: 0.4, isUp: true },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel', price: 890.10, change: -0.2, isUp: false },
  { symbol: 'NIFTY50', name: 'Nifty 50 Index Fund', price: 19500.00, change: 0.9, isUp: true }, // Mutual Fund equivalent
];

export const getMarketData = async (): Promise<Stock[]> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      // Add slight random fluctuation to make it feel "live"
      const liveData = MOCK_STOCKS.map(stock => {
        const fluctuation = (Math.random() - 0.5) * 10;
        const newPrice = Number((stock.price + fluctuation).toFixed(2));
        return {
          ...stock,
          price: newPrice,
          change: stock.change + (Math.random() - 0.5) * 0.1
        };
      });
      resolve(liveData);
    }, 800);
  });
};