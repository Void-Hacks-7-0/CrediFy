// Mock AES Encryption Service
// In a real app, use crypto.subtle or CryptoJS

export const encryptData = (data: string): string => {
  // Simulate encryption by base64 encoding and reversing string
  // This is just for visual demonstration of "scrambled" data
  const base64 = btoa(encodeURIComponent(data));
  return base64.split('').reverse().join('');
};

export const decryptData = (encryptedData: string): string => {
  try {
    const base64 = encryptedData.split('').reverse().join('');
    return decodeURIComponent(atob(base64));
  } catch (e) {
    return "Error decrypting data";
  }
};

export const generateMockSignature = (data: string): string => {
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    hash = (hash << 5) - hash + data.charCodeAt(i);
    hash |= 0;
  }
  return '0x' + Math.abs(hash).toString(16).padStart(64, '0');
}