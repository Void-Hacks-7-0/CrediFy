import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

const SYSTEM_INSTRUCTION = `
You are a friendly, accessible financial advisor named "Credify Bot" designed for students and young workers in India.
Your goal is to improve financial literacy and habits.
Keep your language simple, encouraging, and easy to understand (Grade 6 reading level).
If the user's spending on 'Entertainment' or 'Food' is high, suggest small practical cuts (e.g., "Cook at home twice a week").
Always emphasize saving small amounts.
`;

const getApiKey = () => {
  return (typeof process !== 'undefined' && process.env) ? process.env.API_KEY : '';
};

export const getFinancialAdvice = async (transactions: Transaction[], currentBudget: number): Promise<string> => {
  try {
    const apiKey = getApiKey();
    
    if (!apiKey) {
      return "Gemini API Key is missing. I cannot analyze your data right now, but remember: Save at least 10% of your income!";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Prepare a summary of data to send to the model
    const recentTx = transactions.slice(0, 10).map(t => 
      `${t.date.split('T')[0]}: ${t.type} of ₹${t.amount} on ${t.category} (${t.description})`
    ).join('\n');

    const prompt = `
      My monthly budget is ₹${currentBudget}.
      Here are my recent transactions:
      ${recentTx}
      
      Please provide:
      1. A one-sentence observation about my spending.
      2. One specific, actionable tip to save money next week.
      3. A short "Money Fact" relevant to India (e.g., about SIPs, UPI safety, or Govt schemes).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    return response.text || "Keep tracking your expenses to see better insights!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to the financial brain right now. Please try again later.";
  }
};

export const getFinancialQuiz = async (): Promise<{ question: string; options: string[]; answer: string }> => {
     try {
    const apiKey = getApiKey();

    if (!apiKey) {
      return {
          question: "What is the safest way to pay online?",
          options: ["Share OTP", "Use UPI PIN privately", "Write card number on social media"],
          answer: "Use UPI PIN privately"
      };
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const prompt = `Generate a single multiple-choice question about financial literacy in India (Topics: UPI safety, Savings, or Budgeting). Return ONLY the JSON object.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text || "{}";
    const json = JSON.parse(text);
    
    // Fallback if structure isn't perfect, but usually it works with JSON mode
    return {
        question: json.question || "What is a good savings habit?",
        options: json.options || ["Spend everything", "Save 20%", "Borrow more"],
        answer: json.answer || "Save 20%"
    };

  } catch (error) {
    return {
          question: "What is the safest way to pay online?",
          options: ["Share OTP", "Use UPI PIN privately", "Write card number on social media"],
          answer: "Use UPI PIN privately"
      };
  }
}

export const getBudgetInsight = async (transactions: Transaction[], budgetLimit: number): Promise<string> => {
  try {
    const apiKey = getApiKey();
    if (!apiKey) {
        return "Tip: Switch to local vendors for groceries to save ~15% this month.";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    const expenses = transactions
        .filter(t => t.type === 'EXPENSE')
        .sort((a,b) => b.amount - a.amount)
        .slice(0, 10);

    const totalSpent = expenses.reduce((sum, t) => sum + t.amount, 0);

    const prompt = `
      I have a budget of ₹${budgetLimit}. I have spent ₹${totalSpent} recently.
      Top expenses: ${JSON.stringify(expenses.map(t => ({amt: t.amount, cat: t.category, desc: t.description})))}
      
      Give me ONE single, short, specific, actionable sentence to save money based on these categories.
      Example format: "Save 10% on groceries by switching to [Vendor/Habit]." or "Cut down [Category] spend by [Action]."
      Do not be generic. Be specific to the data provided.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.5,
        maxOutputTokens: 50,
      }
    });

    return response.text || "Track every small expense to identify leaks in your budget.";
  } catch (error) {
     return "Tip: Cooking at home more often can reduce food expenses by up to 30%.";
  }
};