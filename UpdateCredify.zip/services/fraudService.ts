
import { Transaction, TransactionType, FraudAnalysis, TransactionRequest, Category } from '../types';

// Constants for Rules
const VELOCITY_LIMIT = 3; // Max tx per 5 mins
const VELOCITY_WINDOW_MS = 5 * 60 * 1000; // 5 Minutes
const HIGH_VALUE_THRESHOLD = 10000;
const NIGHT_START_HOUR = 2; // 2 AM
const NIGHT_END_HOUR = 5; // 5 AM
const AVERAGE_MULTIPLIER = 3; // Flag if > 3x average

export const analyzeTransaction = (
    request: TransactionRequest,
    history: Transaction[],
    userHomeLocation: string = 'Mumbai' // Default home
): FraudAnalysis => {
    const reasons: string[] = [];
    let riskScore = 0;

    // 1. High Value Check (Threshold Anomaly)
    if (request.amount > HIGH_VALUE_THRESHOLD) {
        reasons.push(`High Value Transaction (>₹${HIGH_VALUE_THRESHOLD})`);
        riskScore += 40;
    }

    // 2. Velocity Check (Rapid Transactions)
    const now = Date.now();
    const recentTx = history.filter(t => {
        const txTime = new Date(t.date).getTime();
        return (now - txTime) < VELOCITY_WINDOW_MS;
    });

    if (recentTx.length >= VELOCITY_LIMIT) {
        reasons.push("High Frequency (Velocity Alert)");
        riskScore += 50;
    }

    // 3. Time-of-Day Anomaly (Night Activity)
    const currentHour = new Date().getHours();
    if (currentHour >= NIGHT_START_HOUR && currentHour < NIGHT_END_HOUR) {
        reasons.push("Unusual Time (Night Activity)");
        riskScore += 30;
    }

    // 4. Geolocation Mismatch (Simulated)
    // In a real app, this comes from navigator.geolocation
    if (request.location && request.location !== userHomeLocation) {
        // If location is provided and different from home
        reasons.push(`Unusual Location: ${request.location}`);
        riskScore += 35;
    }

    // 5. Category Deviation (Spending Pattern)
    if (request.type === TransactionType.EXPENSE) {
        const categoryTx = history.filter(t => t.category === request.category && t.type === TransactionType.EXPENSE);
        
        if (categoryTx.length > 5) {
            const avgSpend = categoryTx.reduce((sum, t) => sum + t.amount, 0) / categoryTx.length;
            if (request.amount > (avgSpend * AVERAGE_MULTIPLIER)) {
                reasons.push(`Abnormal Spend for ${request.category} (>3x Avg)`);
                riskScore += 25;
            }
        }
    }

    return {
        isFraud: riskScore >= 50, // Threshold for flagging
        reasons,
        riskScore: Math.min(100, riskScore)
    };
};
