import { Block, Transaction } from '../types';
import { encryptData } from './encryptionService';

// Simple mock hashing function for demonstration (not real SHA-256)
// In a real app, use crypto.subtle or a library like crypto-js
const simpleHash = (str: string): string => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16).padStart(64, '0');
};

export const createGenesisBlock = (): Block => {
  const timestamp = new Date().toISOString();
  const data = { 
    id: '0', 
    amount: 0, 
    category: 'System', 
    description: 'Genesis Block', 
    date: timestamp, 
    type: 'INCOME' as any 
  };
  
  return {
    index: 0,
    timestamp,
    data,
    previousHash: "0",
    hash: simpleHash("0" + timestamp + "Genesis Block" + "0"),
    encryptedData: encryptData(JSON.stringify(data))
  };
};

export const createBlock = (lastBlock: Block, transaction: Transaction): Block => {
  const timestamp = new Date().toISOString();
  const index = lastBlock.index + 1;
  const previousHash = lastBlock.hash;
  const stringData = JSON.stringify(transaction);
  const hash = simpleHash(index + timestamp + stringData + previousHash);

  return {
    index,
    timestamp,
    data: { ...transaction, hash }, // Store hash in transaction as verification
    previousHash,
    hash,
    encryptedData: encryptData(stringData) // Store encrypted payload
  };
};

export const validateChain = (chain: Block[]): boolean => {
  for (let i = 1; i < chain.length; i++) {
    const current = chain[i];
    const previous = chain[i - 1];

    if (current.previousHash !== previous.hash) {
      return false;
    }
    // Additional validation could go here
  }
  return true;
};