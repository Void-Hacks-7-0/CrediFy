import { TransactionRequest, Transaction, Block, UserProfile, TransactionType, Stock } from "../types";
import { analyzeTransaction } from "./fraudService";

const API_URL = 'http://localhost:5000/api';

const getHeaders = () => ({
  'Content-Type': 'application/json',
  'x-auth-token': localStorage.getItem('credify_token') || ''
});

export const api = {
  // --- AUTH ---
  register: async (name: string, email: string, password: string, pin: string) => {
    try {
      const res = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, pin })
      });
      return await res.json();
    } catch (e) {
      return { msg: 'Server connection failed. Ensure backend is running.' };
    }
  },

  login: async (email: string, password: string) => {
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      return await res.json();
    } catch (e) {
      return { msg: 'Server connection failed. Ensure backend is running.' };
    }
  },

  // --- WALLET DATA ---
  getBalance: async () => {
    try {
        const res = await fetch(`${API_URL}/wallet/balance`, { headers: getHeaders() });
        if (!res.ok) throw new Error('Failed');
        return await res.json();
    } catch (e) {
        // Fallback for initial load if offline
        return { balance: 0, isLocked: false };
    }
  },

  getHistory: async () => {
    try {
        const res = await fetch(`${API_URL}/transaction`, { headers: getHeaders() });
        if (!res.ok) return [];
        // Helper to convert backend blocks to UI format if needed
        const data = await res.json();
        return data; // Backend should return array of blocks
    } catch (e) {
        return [];
    }
  },

  recoverWallet: async (email: string, otp: string) => {
    try {
        const res = await fetch(`${API_URL}/auth/recover`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, otp })
        });
        return await res.json();
    } catch (e) {
        return { success: false, message: "Recovery service unavailable" };
    }
  },

  // --- TRANSACTIONS ---
  sendTransaction: async (req: TransactionRequest, inputPin: string) => {
    try {
      const res = await fetch(`${API_URL}/transaction`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          amount: req.amount,
          category: req.category,
          type: req.type,
          description: req.description,
          receiver: req.receiver,
          transactionPIN: inputPin // Send PIN for verification
        })
      });

      const data = await res.json();
      
      if (!res.ok) {
          return { success: false, message: data.message || "Transaction failed" };
      }

      return {
          success: true,
          fraudAlert: data.fraudAlert,
          message: data.message,
          balance: data.balance
      };

    } catch (e) {
      return { success: false, message: "Network Error: Could not reach server" };
    }
  },

  // --- ADMIN ---
  getAdminData: async () => {
      try {
          const res = await fetch(`${API_URL}/admin/data`, { headers: getHeaders() });
          if (!res.ok) throw new Error("Unauthorized");
          return await res.json();
      } catch (e) {
          return { users: [], flaggedTransactions: [], stats: { totalUsers: 0, totalLiquidity: 0, totalTransactions: 0, flaggedTransactions: 0 }};
      }
  },

  adminUnlockWallet: async (userId: string) => {
      try {
          const res = await fetch(`${API_URL}/admin/unlock`, { 
              method: 'POST',
              headers: getHeaders(),
              body: JSON.stringify({ userId })
          });
          return await res.json();
      } catch (e) {
          return { success: false };
      }
  },

  getSystemLogs: async () => {
      try {
          const res = await fetch(`${API_URL}/admin/logs`, { headers: getHeaders() });
          if (!res.ok) return [];
          return await res.json();
      } catch (e) {
          return [];
      }
  }
};