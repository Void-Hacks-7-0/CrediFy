const User = require('../models/User');
const Transaction = require('../models/Transaction');
const FraudLog = require('../models/FraudLog');

exports.getBalance = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password -pin');
    res.json({ balance: user.balance, isLocked: user.isWalletLocked });
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

exports.getHistory = async (req, res) => {
  try {
    const transactions = await Transaction.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(20);
    res.json(transactions);
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

exports.getFraudLogs = async (req, res) => {
  try {
    const logs = await FraudLog.find({ userId: req.user.id }).sort({ timestamp: -1 });
    res.json(logs);
  } catch (err) {
    res.status(500).send('Server Error');
  }
};

exports.lockWallet = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    user.isWalletLocked = true;
    user.lockUntil = new Date(Date.now() + 60 * 60 * 1000); // 1 Hour manual lock
    await user.save();
    res.json({ msg: "Wallet Locked Successfully" });
  } catch (err) {
    res.status(500).send('Server Error');
  }
};