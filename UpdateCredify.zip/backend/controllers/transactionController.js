const Transaction = require('../models/Transaction');
const User = require('../models/User');
const { createBlock } = require('../services/blockchain');

exports.processTransaction = async (req, res) => {
  const { amount, category, description, type, receiver } = req.body;
  const userId = req.user.id;
  const fraudData = req.fraudAnalysis;

  try {
    const user = await User.findById(userId);

    // 1. Logic for Balance Updates
    if (type === 'INCOME') {
      user.balance += amount;
    } 
    else if (type === 'CONTRACT_LOCK') {
       if (user.balance < amount) return res.status(400).json({ success: false, message: "Insufficient Balance" });
       user.balance -= amount;
       user.lockedBalance += amount;
    }
    else if (type === 'CONTRACT_UNLOCK') {
       // Unlock: Move from locked to available
       // Note: In real app, check specific contract ID logic
       if (user.lockedBalance < amount) return res.status(400).json({ success: false, message: "Funds are locked" });
       user.lockedBalance -= amount;
       user.balance += amount;
    }
    else {
      // Expense, Transfer, Investment
      if (user.balance < amount) {
        return res.status(400).json({ success: false, message: "Insufficient Balance" });
      }
      user.balance -= amount;

      // Rewards Logic (Earn SecureCoin on expenses)
      if (type === 'EXPENSE') {
          user.tokenBalance = (user.tokenBalance || 0) + Math.floor(amount / 100); // 1 Coin per 100 spent
      }
      
      // Investment Logic (Update Portfolio Mock)
      if (type === 'INVESTMENT') {
          // Simplified: In production, we'd parse the description or pass specific stock data
          // Here we just deduct money. The frontend manages the portfolio UI state for now
          // or we can push to user.portfolio here if we passed the stock details
      }
    }

    // 2. Prepare Transaction Data
    const txData = {
      userId,
      amount,
      category,
      type,
      description,
      receiver,
      isSuspicious: fraudData.isFraud,
      fraudReason: fraudData.reasons.join(', ')
    };

    // 3. Write to Blockchain
    const newBlock = await createBlock(userId, txData);
    
    // 4. Update MongoDB Transaction Record
    const transaction = new Transaction({
      ...txData,
      blockchainHash: newBlock.hash,
      status: fraudData.isFraud ? 'FLAGGED' : 'SUCCESS'
    });
    await transaction.save();
    await user.save();

    // 5. Response
    if (fraudData.isFraud) {
      return res.json({
        success: true, 
        message: "Transaction processed but flagged for review.",
        fraudAlert: true,
        hash: newBlock.hash,
        balance: user.balance
      });
    }

    res.json({
      success: true,
      message: "Transaction Successful",
      hash: newBlock.hash,
      balance: user.balance
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Transaction Failed" });
  }
};