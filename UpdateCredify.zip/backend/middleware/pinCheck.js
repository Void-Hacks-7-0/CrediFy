const User = require('../models/User');
const bcrypt = require('bcryptjs');

const verifyPIN = async (req, res, next) => {
  const { transactionPIN } = req.body;
  const userId = req.user.id;

  try {
    const user = await User.findById(userId);

    // 1. Check if Wallet is Locked
    if (user.isWalletLocked) {
      if (user.lockUntil && new Date() < user.lockUntil) {
        const minutesLeft = Math.ceil((user.lockUntil - new Date()) / 60000);
        return res.status(403).json({ 
          success: false, 
          message: `Wallet locked. Try again in ${minutesLeft} minutes.` 
        });
      } else {
        // Unlock if time passed
        user.isWalletLocked = false;
        user.failedPINAttempts = 0;
        user.lockUntil = null;
        await user.save();
      }
    }

    // 2. Verify PIN
    const isMatch = await bcrypt.compare(transactionPIN, user.pin);

    if (!isMatch) {
      user.failedPINAttempts += 1;
      
      // Lock Logic
      if (user.failedPINAttempts >= 3) {
        user.isWalletLocked = true;
        user.lockUntil = new Date(Date.now() + 15 * 60 * 1000); // 15 Minutes
        await user.save();
        return res.status(403).json({ 
          success: false, 
          message: "Invalid PIN. Wallet LOCKED for 15 minutes." 
        });
      }

      await user.save();
      return res.status(401).json({ 
        success: false, 
        message: `Invalid PIN. ${3 - user.failedPINAttempts} attempts remaining.` 
      });
    }

    // 3. Reset attempts on success
    user.failedPINAttempts = 0;
    await user.save();
    next();

  } catch (err) {
    console.error("PIN Middleware Error:", err);
    res.status(500).json({ message: "Server Error during PIN check" });
  }
};

module.exports = verifyPIN;