const Transaction = require('../models/Transaction');
const FraudLog = require('../models/FraudLog');

const fraudDetection = async (req, res, next) => {
  const { amount, category } = req.body;
  const userId = req.user.id;

  let isFraud = false;
  let reasons = [];
  let riskScore = 0;

  try {
    // Rule 1: High Value Threshold
    // Assuming hard limit of 10,000 for demo. Real app calculates avg.
    if (amount > 10000) {
      isFraud = true;
      reasons.push("High Value Transaction (> 10,000)");
      riskScore += 40;
    }

    // Rule 2: Velocity Check (More than 3 tx in 30 seconds)
    const thirtySecondsAgo = new Date(Date.now() - 30 * 1000);
    const recentTxCount = await Transaction.countDocuments({
      userId,
      createdAt: { $gte: thirtySecondsAgo }
    });

    if (recentTxCount >= 3) {
      isFraud = true;
      reasons.push("Velocity Limit Exceeded (Too many requests)");
      riskScore += 50;
    }

    // Rule 3: Category Anomaly (Mock logic)
    // If amount > 5000 in 'Food', it's weird.
    if (category === 'Food' && amount > 5000) {
      isFraud = true;
      reasons.push("Category Anomaly: High spend on Food");
      riskScore += 30;
    }

    req.fraudAnalysis = {
      isFraud,
      reasons,
      riskScore: Math.min(riskScore, 100)
    };

    // Log Fraud if detected
    if (isFraud) {
      const log = new FraudLog({
        userId,
        amount,
        category,
        reason: reasons.join(', '),
        riskScore
      });
      await log.save();
    }

    next();

  } catch (err) {
    console.error("Fraud Engine Error:", err);
    next(); // Don't block flow on engine error, but log it
  }
};

module.exports = fraudDetection;