const crypto = require('crypto');
const Block = require('../models/Block');

// SHA-256 Hashing
const calculateHash = (index, previousHash, timestamp, data, nonce) => {
  return crypto
    .createHash('sha256')
    .update(index + previousHash + timestamp + JSON.stringify(data) + nonce)
    .digest('hex');
};

const createBlock = async (userId, transactionData) => {
  // Get last block for this user (User-specific chain)
  const lastBlock = await Block.findOne({ userId }).sort({ index: -1 });
  
  const index = lastBlock ? lastBlock.index + 1 : 0;
  const previousHash = lastBlock ? lastBlock.hash : "00000000000000000000000000000000";
  const timestamp = new Date();
  const nonce = Math.floor(Math.random() * 100000); // Simple nonce
  
  const hash = calculateHash(index, previousHash, timestamp, transactionData, nonce);
  
  const newBlock = new Block({
    index,
    timestamp,
    userId,
    data: transactionData,
    previousHash,
    hash,
    nonce
  });

  await newBlock.save();
  return newBlock;
};

module.exports = { createBlock };