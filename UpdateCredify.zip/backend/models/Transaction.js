const mongoose = require('mongoose');

const TransactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true },
  category: { type: String, required: true },
  type: { type: String, enum: ['INCOME', 'EXPENSE', 'TRANSFER'], required: true },
  description: { type: String },
  receiver: { type: String }, // Mobile or Account
  
  // Security & Blockchain
  status: { type: String, enum: ['SUCCESS', 'FAILED', 'FLAGGED'], default: 'SUCCESS' },
  blockchainHash: { type: String, required: true },
  isSuspicious: { type: Boolean, default: false },
  fraudReason: { type: String },
  
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Transaction', TransactionSchema);