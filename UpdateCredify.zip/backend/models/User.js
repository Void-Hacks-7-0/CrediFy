const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  pin: { type: String, required: true }, // Hashed
  balance: { type: Number, default: 0 },
  
  // Advanced Balances
  lockedBalance: { type: Number, default: 0 },
  tokenBalance: { type: Number, default: 0 },
  
  // Security Fields
  isWalletLocked: { type: Boolean, default: false },
  lockUntil: { type: Date, default: null },
  failedPINAttempts: { type: Number, default: 0 },
  
  // Profile
  did: { type: String }, // Decentralized ID
  trustScore: { type: Number, default: 100 },
  
  // Features
  portfolio: [{
    symbol: String,
    name: String,
    quantity: Number,
    avgPrice: Number
  }],
  
  linkedBanks: [{
    id: String,
    bankName: String,
    accountNumber: String,
    ifsc: String,
    isPrimary: Boolean
  }],

  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', UserSchema);