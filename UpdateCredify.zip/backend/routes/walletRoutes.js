const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { getBalance, getHistory, getFraudLogs, lockWallet } = require('../controllers/walletController');

router.get('/balance', auth, getBalance);
router.get('/history', auth, getHistory);
router.get('/fraud', auth, getFraudLogs);
router.post('/lock', auth, lockWallet);

module.exports = router;