const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const verifyPIN = require('../middleware/pinCheck');
const fraudDetection = require('../middleware/fraudCheck');
const { processTransaction } = require('../controllers/transactionController');

// The Golden Route: Auth -> PIN -> Fraud -> Process
router.post('/', auth, verifyPIN, fraudDetection, processTransaction);

module.exports = router;