# 🚀 Credify – Blockchain-Powered Personal Finance Tracker

**Credify** is a secure, inclusive, and blockchain-integrated personal finance application designed to promote financial literacy and security for underserved communities in India. 

It combines the simplicity of UPI apps with the transparency of blockchain technology and the intelligence of AI to help users manage expenses, detect fraud, and grow their wealth.

---

## 🌟 Key Features

### 🛡️ Security & Blockchain
*   **Immutable Ledger**: Every transaction is hashed and "stored" on a local blockchain simulation, ensuring transparency.
*   **Mandatory PIN Verification**: Every financial action (Add Money, Transfer, Pay Bill) requires a 4-digit PIN.
*   **Fraud Detection Engine**: Real-time analysis flags transactions based on:
    *   Velocity (Too many tx in short time).
    *   High Value Thresholds.
    *   Unusual Time (Night activity).
    *   Category Deviation.
*   **Wallet Locking**: Automatically locks account after 3 incorrect PIN attempts.

### 💰 Financial Management
*   **UPI-Style Dashboard**: Scan QR, Pay to Mobile, Self Transfer, and Bill Payments.
*   **Smart Expenses**: Voice-activated expense entry (e.g., "Spent 50 on Food").
*   **Smart Contracts**: Lock funds for specific goals (Rent, Emergency Fund) that cannot be withdrawn until a set date.
*   **Investments**: Live stock market simulation (NSE/BSE) and Portfolio tracking.

### 🧠 AI & Education (Powered by Google Gemini)
*   **AI Financial Advisor**: Get personalized saving tips based on your spending patterns.
*   **Financial Literacy Quiz**: Earn "SecureCoin" (SRC) tokens by learning about SIPs, Mutual Funds, and Govt Schemes.
*   **Multilingual**: Full support for **English** and **Hindi**.

---

## 🛠️ Tech Stack

*   **Frontend**: React.js (v18+), TypeScript, Tailwind CSS
*   **State Management**: React Hooks
*   **AI Integration**: Google Gemini API (`@google/genai`)
*   **Security**: bcryptjs (Simulated), Custom Fraud Engine
*   **Icons**: Lucide React

---

## 🚀 Getting Started

### Prerequisites
*   Node.js (v16 or higher)
*   npm or yarn

### Installation

1.  **Clone the repository**
    ```bash
    git clone https://github.com/yourusername/credify.git
    cd credify
    ```

2.  **Install Dependencies**
    ```bash
    npm install
    ```

3.  **Configure Environment**
    Create a `.env` file in the root directory if you want to use real AI features:
    ```env
    REACT_APP_GEMINI_API_KEY=your_google_gemini_api_key
    ```
    *(Note: The app handles missing keys gracefully with fallback mock data)*

4.  **Run the Application**
    ```bash
    npm start
    ```
    Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

---

## 📱 Usage Guide

### 1. Sign Up / Login
*   **New User**: Go to "Sign Up", enter Name, Email, and set a **4-Digit Security PIN**.
*   **Demo Credentials**: You can create any account. Data persists in your browser's LocalStorage.

### 2. Dashboard
*   **Add Money**: Click "Add Money" -> Enter Amount -> Enter PIN.
*   **Scan QR**: Click "Scan QR" -> Simulate Scan -> Pay.
*   **Check Ledger**: Go to the "Wallet" tab to see the blockchain hash of every transaction.

### 3. Testing Fraud Detection
*   **Velocity Fraud**: Try making 4-5 small transactions within 1 minute. The system will flag them as "Suspicious".
*   **High Value**: Try transferring > ₹10,000. It will be flagged.
*   **Incorrect PIN**: Enter the wrong PIN 3 times to see the Wallet Lock mechanism.

### 4. Smart Contracts
*   Go to "Contracts" tab.
*   Create a "Time Lock" contract for Rent.
*   Try to withdraw it instantly (You won't be able to until the date passes).

---

## 📂 Project Structure

```
/src
  /components       # UI Components (Dashboard, Wallet, Login, etc.)
  /services         # Logic Layer
    - api.ts        # Mock Backend (Auth, Ledger, Logic)
    - blockchain.ts # Hashing & Block creation
    - fraud.ts      # Fraud Detection Rules
    - gemini.ts     # AI Integration
  /types.ts         # TypeScript Interfaces
  App.tsx           # Main Router & State
```

---

## 🔮 Future Roadmap
*   **Real Blockchain Integration**: Move from local hash simulation to Polygon/Ethereum Testnet.
*   **P2P Mesh Network**: Allow offline transactions between devices.
*   **Govt API Integration**: Real-time fetching of DBT (Direct Benefit Transfer) status.

---

Made with ❤️ for Financial Inclusion.
