
import React, { useState, useEffect } from 'react';
import { ShieldCheck, Delete, X, LockKeyhole, AlertTriangle } from 'lucide-react';

interface PinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (pin: string) => void;
  attempts: number;
  reason?: string; // If this is a fraud verification
}

const PinModal: React.FC<PinModalProps> = ({ isOpen, onClose, onSubmit, attempts, reason }) => {
  const [pin, setPin] = useState('');
  const [shake, setShake] = useState(false);

  useEffect(() => {
    // RESET PIN logic: whenever the modal opens, clear the PIN state.
    if (isOpen) {
        setPin('');
    }
  }, [isOpen]);

  useEffect(() => {
    if (attempts > 0) {
      setPin('');
      setShake(true);
      const timer = setTimeout(() => setShake(false), 500);
      return () => clearTimeout(timer);
    }
  }, [attempts]);

  if (!isOpen) return null;

  const handleNumberClick = (num: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + num);
    }
  };

  const handleDelete = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleSubmit = () => {
    if (pin.length === 4) {
      onSubmit(pin);
      // Don't clear PIN here immediately, wait for re-open or error
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md animate-fade-in p-4">
      <div className={`bg-white dark:bg-slate-900 w-full max-w-xs rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden ${shake ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}>
        
        {/* Header */}
        <div className="bg-slate-50 dark:bg-slate-800 p-6 text-center relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">
            <X size={20} />
          </button>
          
          <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center mx-auto mb-3">
            {reason ? <AlertTriangle className="text-amber-500" size={24} /> : <LockKeyhole className="text-indigo-600 dark:text-indigo-400" size={24} />}
          </div>
          
          <h3 className="text-lg font-bold text-slate-800 dark:text-white">
            {reason ? 'Verify Suspicious Transaction' : 'Enter Secure PIN'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {reason ? reason : 'Please verify your identity to proceed.'}
          </p>
        </div>

        {/* PIN Display */}
        <div className="py-6 flex justify-center space-x-4 bg-white dark:bg-slate-900">
          {[0, 1, 2, 3].map((i) => (
            <div 
              key={i} 
              className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                pin.length > i 
                  ? 'bg-indigo-600 border-indigo-600 scale-110' 
                  : 'bg-transparent border-slate-300 dark:border-slate-600'
              }`}
            ></div>
          ))}
        </div>

        {/* Error Message */}
        {attempts > 0 && (
          <p className="text-center text-xs text-red-500 font-bold mb-2">
            Incorrect PIN. {3 - attempts} attempts left.
          </p>
        )}

        {/* Keypad */}
        <div className="p-4 pb-8 bg-slate-50 dark:bg-slate-950">
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handleNumberClick(num.toString())}
                className="h-14 rounded-xl bg-white dark:bg-slate-800 shadow-sm border-b-2 border-slate-200 dark:border-slate-700 text-xl font-bold text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-95 transition-all"
              >
                {num}
              </button>
            ))}
            <div className="flex items-center justify-center">
               <ShieldCheck className="text-emerald-500" size={24}/>
            </div>
            <button
              onClick={() => handleNumberClick('0')}
              className="h-14 rounded-xl bg-white dark:bg-slate-800 shadow-sm border-b-2 border-slate-200 dark:border-slate-700 text-xl font-bold text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-95 transition-all"
            >
              0
            </button>
            <button
              onClick={handleDelete}
              className="h-14 rounded-xl flex items-center justify-center text-slate-500 hover:text-red-500 transition-colors"
            >
              <Delete size={24} />
            </button>
          </div>
          
          <button 
            onClick={handleSubmit}
            disabled={pin.length !== 4}
            className="w-full mt-6 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl shadow-lg transition-all active:scale-95"
          >
            Verify Transaction
          </button>
        </div>

      </div>
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
      `}</style>
    </div>
  );
};

export default PinModal;
