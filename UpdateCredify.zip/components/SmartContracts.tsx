import React, { useState } from 'react';
import { SmartContract, ContractType } from '../types';
import { Lock, Unlock, Shield, AlertTriangle, Clock, Plus, CheckCircle } from 'lucide-react';

interface SmartContractsProps {
  contracts: SmartContract[];
  onCreateContract: (contract: SmartContract) => void;
  onWithdraw: (id: string) => void;
}

const SmartContracts: React.FC<SmartContractsProps> = ({ contracts, onCreateContract, onWithdraw }) => {
  const [showForm, setShowForm] = useState(false);
  const [contractType, setContractType] = useState<ContractType>(ContractType.TIME_LOCK);
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [unlockDate, setUnlockDate] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!name || !amount) return;
      
      const newContract: SmartContract = {
          id: Date.now().toString(),
          type: contractType,
          name,
          amount: parseFloat(amount),
          creationDate: new Date().toISOString(),
          unlockDate: contractType === ContractType.TIME_LOCK ? unlockDate : undefined,
          status: 'ACTIVE',
          hash: '0x' + Math.random().toString(16).substr(2, 40) // Mock Hash
      };
      
      onCreateContract(newContract);
      setShowForm(false);
      setName('');
      setAmount('');
      setUnlockDate('');
  };

  const activeContracts = contracts.filter(c => c.status === 'ACTIVE');
  const executedContracts = contracts.filter(c => c.status === 'EXECUTED');

  return (
    <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-end">
            <div>
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center">
                    <FileCodeIcon className="mr-2 text-indigo-600 dark:text-indigo-400" />
                    Smart Contracts
                </h2>
                <p className="text-slate-500 dark:text-slate-400">Programmable money. Lock funds for rent, fees, or emergencies.</p>
            </div>
            <button 
                onClick={() => setShowForm(!showForm)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium flex items-center shadow-md transition-all active:scale-95"
            >
                <Plus size={16} className="mr-2" />
                New Contract
            </button>
        </div>

        {showForm && (
            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-lg border border-indigo-100 dark:border-indigo-900 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 dark:bg-indigo-900/20 rounded-bl-full -mr-8 -mt-8"></div>
                <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-4 relative z-10">Deploy New Contract</h3>
                
                <div className="flex space-x-4 mb-6 relative z-10">
                    <button 
                        onClick={() => setContractType(ContractType.TIME_LOCK)}
                        className={`flex-1 p-3 rounded-xl border-2 flex flex-col items-center justify-center transition-all ${contractType === ContractType.TIME_LOCK ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-indigo-200'}`}
                    >
                        <Clock size={24} className="mb-2" />
                        <span className="font-bold text-sm">Time Lock</span>
                        <span className="text-xs text-center mt-1 opacity-70">Lock funds until a specific date (e.g., Rent)</span>
                    </button>
                    <button 
                        onClick={() => setContractType(ContractType.EMERGENCY_FUND)}
                        className={`flex-1 p-3 rounded-xl border-2 flex flex-col items-center justify-center transition-all ${contractType === ContractType.EMERGENCY_FUND ? 'border-red-500 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-red-200'}`}
                    >
                        <Shield size={24} className="mb-2" />
                        <span className="font-bold text-sm">Emergency Fund</span>
                        <span className="text-xs text-center mt-1 opacity-70">Lock funds for emergencies only.</span>
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Contract Name</label>
                            <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. December Rent" className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount (₹)</label>
                            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
                        </div>
                    </div>
                    {contractType === ContractType.TIME_LOCK && (
                        <div>
                             <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Unlock Date</label>
                             <input type="date" value={unlockDate} onChange={e => setUnlockDate(e.target.value)} className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
                        </div>
                    )}
                    <div className="pt-2 flex space-x-3">
                        <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 border rounded-xl text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-700 dark:border-slate-600">Cancel</button>
                        <button type="submit" className="flex-1 bg-indigo-600 text-white py-2 rounded-xl font-medium shadow-md hover:bg-indigo-700 transition-colors">Deploy to Blockchain</button>
                    </div>
                </form>
            </div>
        )}

        {/* Active Contracts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activeContracts.length === 0 && !showForm && (
                <div className="col-span-2 text-center py-10 bg-white dark:bg-slate-800 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
                    <p className="text-slate-400 mb-2">No active smart contracts.</p>
                    <button onClick={() => setShowForm(true)} className="text-indigo-600 font-medium text-sm hover:underline">Create one to secure your funds</button>
                </div>
            )}
            
            {activeContracts.map(contract => (
                <div key={contract.id} className="bg-white dark:bg-slate-800 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-700 relative overflow-hidden group hover:shadow-md transition-all">
                     <div className={`absolute top-0 left-0 w-1 h-full ${contract.type === ContractType.EMERGENCY_FUND ? 'bg-red-500' : 'bg-indigo-500'}`}></div>
                     
                     <div className="flex justify-between items-start mb-3 pl-3">
                         <div>
                             <div className="flex items-center space-x-2">
                                {contract.type === ContractType.EMERGENCY_FUND ? <Shield size={16} className="text-red-500" /> : <Clock size={16} className="text-indigo-500" />}
                                <h4 className="font-bold text-slate-800 dark:text-white">{contract.name}</h4>
                             </div>
                             <p className="text-[10px] text-slate-400 font-mono mt-1">Hash: {contract.hash.substring(0, 12)}...</p>
                         </div>
                         <div className="bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded text-xs font-bold text-slate-700 dark:text-slate-200">
                             ₹{contract.amount.toLocaleString()}
                         </div>
                     </div>
                     
                     <div className="pl-3 mb-4">
                         <p className="text-xs text-slate-500 dark:text-slate-400">
                             {contract.type === ContractType.TIME_LOCK 
                                ? `Locked until ${new Date(contract.unlockDate!).toLocaleDateString()}` 
                                : "Locked indefinitely. Use only in emergency."}
                         </p>
                     </div>

                     <button 
                        onClick={() => onWithdraw(contract.id)}
                        className={`w-full py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors ml-1
                            ${contract.type === ContractType.EMERGENCY_FUND 
                                ? 'bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:text-red-400 dark:hover:bg-red-900/40' 
                                : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-900/20 dark:text-indigo-400 dark:hover:bg-indigo-900/40'}
                        `}
                     >
                        {contract.type === ContractType.EMERGENCY_FUND ? 'Break Emergency Seal' : 'Withdraw Funds'}
                     </button>
                </div>
            ))}
        </div>

        {/* History */}
        {executedContracts.length > 0 && (
            <div className="mt-8">
                <h3 className="text-sm font-semibold text-slate-500 dark:text-slate-400 mb-4 uppercase tracking-wider">Executed Contracts</h3>
                <div className="space-y-3">
                    {executedContracts.map(c => (
                        <div key={c.id} className="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 opacity-70">
                             <div className="flex items-center space-x-3">
                                 <CheckCircle size={18} className="text-green-500" />
                                 <span className="font-medium text-slate-700 dark:text-slate-300">{c.name}</span>
                             </div>
                             <span className="text-sm font-bold text-slate-600 dark:text-slate-400">₹{c.amount.toLocaleString()}</span>
                        </div>
                    ))}
                </div>
            </div>
        )}
    </div>
  );
};

const FileCodeIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="m10 13-2 2 2 2"/><path d="m14 17 2-2-2-2"/></svg>
)

export default SmartContracts;