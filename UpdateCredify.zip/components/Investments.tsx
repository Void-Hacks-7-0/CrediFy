import React, { useEffect, useState } from 'react';
import { Stock, PortfolioItem, UserProfile } from '../types';
import { getMarketData } from '../services/stockService';
import { TrendingUp, TrendingDown, PieChart, RefreshCw, Briefcase, PlusCircle, ArrowUpRight } from 'lucide-react';

interface InvestmentsProps {
  user: UserProfile;
  onBuyStock: (stock: Stock, quantity: number) => void;
}

const Investments: React.FC<InvestmentsProps> = ({ user, onBuyStock }) => {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [quantity, setQuantity] = useState('1');

  const fetchStocks = async () => {
    setLoading(true);
    const data = await getMarketData();
    setStocks(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchStocks();
    const interval = setInterval(fetchStocks, 10000); // Live update every 10s
    return () => clearInterval(interval);
  }, []);

  const handleBuy = () => {
    if (selectedStock && quantity) {
        onBuyStock(selectedStock, parseInt(quantity));
        setSelectedStock(null);
        setQuantity('1');
    }
  };

  const totalPortfolioValue = user.portfolio.reduce((acc, item) => {
      const currentStock = stocks.find(s => s.symbol === item.symbol);
      const price = currentStock ? currentStock.price : item.avgPrice;
      return acc + (item.quantity * price);
  }, 0);

  const totalInvested = user.portfolio.reduce((acc, item) => acc + (item.quantity * item.avgPrice), 0);
  const totalReturn = totalPortfolioValue - totalInvested;
  const returnPercentage = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;

  return (
    <div className="space-y-6 animate-fade-in">
        
        {/* Portfolio Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden col-span-2">
                <div className="relative z-10">
                    <h2 className="text-blue-100 text-sm font-medium uppercase tracking-wider mb-1">Total Portfolio Value</h2>
                    <div className="flex items-baseline space-x-2">
                         <span className="text-4xl font-extrabold">₹{totalPortfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    </div>
                    
                    <div className="mt-6 flex space-x-6">
                        <div>
                            <p className="text-xs text-blue-200 mb-1">Invested</p>
                            <p className="font-bold">₹{totalInvested.toLocaleString()}</p>
                        </div>
                        <div>
                            <p className="text-xs text-blue-200 mb-1">Total Returns</p>
                            <p className={`font-bold flex items-center ${totalReturn >= 0 ? 'text-green-300' : 'text-red-300'}`}>
                                {totalReturn >= 0 ? '+' : ''}₹{totalReturn.toLocaleString()} 
                                <span className="text-xs ml-1 bg-white/20 px-1.5 rounded">
                                    {returnPercentage.toFixed(2)}%
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
                <PieChart className="absolute right-4 bottom-4 text-white opacity-10 w-32 h-32" />
            </div>

            {/* Buying Power */}
            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col justify-center">
                <p className="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-wider mb-2">Wallet Balance</p>
                <p className="text-3xl font-bold text-slate-800 dark:text-white">₹{user.balance.toLocaleString()}</p>
                <p className="text-xs text-slate-400 mt-2">Use this balance to invest.</p>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Market List */}
            <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden">
                <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
                    <h3 className="font-bold text-slate-800 dark:text-white flex items-center">
                        <TrendingUp className="mr-2 text-indigo-600" size={20} />
                        Live Market (NSE/BSE)
                    </h3>
                    <button onClick={fetchStocks} className="text-slate-400 hover:text-indigo-600 transition-colors">
                        <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
                    </button>
                </div>
                
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-slate-50 dark:bg-slate-900 text-xs text-slate-500 dark:text-slate-400 uppercase">
                            <tr>
                                <th className="p-4 font-medium">Instrument</th>
                                <th className="p-4 font-medium">Price</th>
                                <th className="p-4 font-medium">24h Change</th>
                                <th className="p-4 font-medium text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                            {stocks.map(stock => (
                                <tr key={stock.symbol} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                                    <td className="p-4">
                                        <p className="font-bold text-slate-800 dark:text-white text-sm">{stock.symbol}</p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">{stock.name}</p>
                                    </td>
                                    <td className="p-4 text-sm font-medium text-slate-800 dark:text-slate-200">
                                        ₹{stock.price.toFixed(2)}
                                    </td>
                                    <td className="p-4">
                                        <div className={`flex items-center text-xs font-bold px-2 py-1 rounded w-fit ${stock.isUp ? 'text-green-600 bg-green-50 dark:bg-green-900/20' : 'text-red-600 bg-red-50 dark:bg-red-900/20'}`}>
                                            {stock.isUp ? <TrendingUp size={12} className="mr-1" /> : <TrendingDown size={12} className="mr-1" />}
                                            {stock.change.toFixed(2)}%
                                        </div>
                                    </td>
                                    <td className="p-4 text-right">
                                        <button 
                                            onClick={() => setSelectedStock(stock)}
                                            className="text-xs bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-900/50 px-3 py-1.5 rounded-lg transition-colors font-medium"
                                        >
                                            Buy
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Holdings & Buy Panel */}
            <div className="space-y-6">
                
                {/* Buy Panel (If selected) */}
                {selectedStock && (
                    <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl shadow-lg border-2 border-indigo-500 animate-in fade-in slide-in-from-right-4 duration-300">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h4 className="font-bold text-lg text-slate-800 dark:text-white">Buy {selectedStock.symbol}</h4>
                                <p className="text-xs text-slate-500">Current Price: ₹{selectedStock.price}</p>
                            </div>
                            <button onClick={() => setSelectedStock(null)} className="text-slate-400 hover:text-slate-600 text-sm">Cancel</button>
                        </div>
                        
                        <div className="space-y-4">
                            <div>
                                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Quantity</label>
                                <input 
                                    type="number" 
                                    min="1"
                                    value={quantity}
                                    onChange={(e) => setQuantity(e.target.value)}
                                    className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg dark:text-white"
                                />
                            </div>
                            <div className="flex justify-between text-sm font-medium">
                                <span className="text-slate-500">Total Cost:</span>
                                <span className="text-slate-800 dark:text-white">₹{(parseFloat(quantity || '0') * selectedStock.price).toFixed(2)}</span>
                            </div>
                            <button 
                                onClick={handleBuy}
                                disabled={parseFloat(quantity) * selectedStock.price > user.balance}
                                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-xl font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {parseFloat(quantity) * selectedStock.price > user.balance ? "Insufficient Balance" : "Confirm Investment"}
                            </button>
                        </div>
                    </div>
                )}

                {/* Holdings List */}
                <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700">
                    <h3 className="font-bold text-slate-800 dark:text-white flex items-center mb-4">
                        <Briefcase className="mr-2 text-indigo-600" size={18} />
                        Your Holdings
                    </h3>
                    
                    <div className="space-y-3">
                        {user.portfolio.length === 0 ? (
                            <p className="text-sm text-slate-400 text-center py-4">No investments yet.</p>
                        ) : (
                            user.portfolio.map((item, idx) => {
                                const currentPrice = stocks.find(s => s.symbol === item.symbol)?.price || item.avgPrice;
                                const val = currentPrice * item.quantity;
                                const gain = val - (item.avgPrice * item.quantity);
                                
                                return (
                                    <div key={idx} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                                        <div>
                                            <p className="font-bold text-sm text-slate-800 dark:text-white">{item.symbol}</p>
                                            <p className="text-xs text-slate-500">{item.quantity} qty @ ₹{item.avgPrice}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-bold text-sm text-slate-800 dark:text-white">₹{val.toFixed(0)}</p>
                                            <p className={`text-xs font-medium ${gain >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                                                {gain >= 0 ? '+' : ''}{gain.toFixed(0)}
                                            </p>
                                        </div>
                                    </div>
                                )
                            })
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Investments;