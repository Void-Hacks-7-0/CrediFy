
import React, { useState } from 'react';
import { SavingsGoal } from '../types';
import { Plus, Target, Trophy, ArrowRight } from 'lucide-react';

interface GoalsProps {
  goals: SavingsGoal[];
  balance: number;
  onAddGoal: (goal: SavingsGoal) => void;
  onContribute: (id: string, amount: number) => void;
}

const Goals: React.FC<GoalsProps> = ({ goals, balance, onAddGoal, onContribute }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [target, setTarget] = useState('');
  const [deadline, setDeadline] = useState('');
  const [contributeAmounts, setContributeAmounts] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !target) return;

    onAddGoal({
      id: Date.now().toString(),
      name,
      targetAmount: parseFloat(target),
      currentAmount: 0,
      deadline,
      color: `bg-${['blue', 'purple', 'emerald', 'orange'][Math.floor(Math.random()*4)]}-500`
    });

    setName('');
    setTarget('');
    setDeadline('');
    setShowAdd(false);
  };

  const handleContributeClick = (id: string) => {
    const amount = parseFloat(contributeAmounts[id]);
    if (amount > 0) {
        onContribute(id, amount);
        setContributeAmounts(prev => ({...prev, [id]: ''}));
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-end">
            <div>
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Financial Goals</h2>
                <p className="text-slate-500 dark:text-slate-400">Save for what matters to you.</p>
            </div>
            <div className="text-right">
                <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wide font-semibold">Wallet Balance</p>
                <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">₹{balance.toLocaleString()}</p>
            </div>
        </div>

        {/* Add Goal Form */}
        {showAdd ? (
            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                <h3 className="font-semibold text-slate-800 dark:text-white mb-4">Create New Goal</h3>
                <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div>
                        <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Goal Name</label>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full p-2 border rounded-lg dark:bg-slate-900 dark:border-slate-700 dark:text-white" placeholder="e.g. Laptop" />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Target Amount (₹)</label>
                        <input type="number" value={target} onChange={e => setTarget(e.target.value)} className="w-full p-2 border rounded-lg dark:bg-slate-900 dark:border-slate-700 dark:text-white" placeholder="10000" />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Deadline</label>
                        <input type="date" value={deadline} onChange={e => setDeadline(e.target.value)} className="w-full p-2 border rounded-lg dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
                    </div>
                    <div className="flex space-x-2">
                        <button type="submit" className="flex-1 bg-indigo-600 text-white py-2 rounded-lg font-medium">Create</button>
                        <button type="button" onClick={() => setShowAdd(false)} className="px-4 py-2 border rounded-lg text-slate-600 dark:text-slate-400 dark:border-slate-600">Cancel</button>
                    </div>
                </form>
            </div>
        ) : (
            <button onClick={() => setShowAdd(true)} className="w-full py-4 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl text-slate-500 dark:text-slate-400 font-medium hover:border-indigo-400 dark:hover:border-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all flex items-center justify-center space-x-2">
                <Plus size={20} />
                <span>Add New Goal</span>
            </button>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {goals.map(goal => {
                const progress = Math.min(100, (goal.currentAmount / goal.targetAmount) * 100);
                const isComplete = progress >= 100;

                return (
                    <div key={goal.id} className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col justify-between h-full relative overflow-hidden group">
                        {isComplete && <div className="absolute inset-0 bg-yellow-50/50 dark:bg-yellow-900/20 z-0 flex items-center justify-center pointer-events-none"><Trophy className="text-yellow-400 opacity-20 w-32 h-32" /></div>}
                        
                        <div className="relative z-10">
                            <div className="flex justify-between items-start mb-4">
                                <div className={`p-3 rounded-xl ${isComplete ? 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400'}`}>
                                    {isComplete ? <Trophy size={24} /> : <Target size={24} />}
                                </div>
                                <div className="text-right">
                                    <span className="text-xs text-slate-400 dark:text-slate-500 block">Target</span>
                                    <span className="font-bold text-slate-800 dark:text-white">₹{goal.targetAmount.toLocaleString()}</span>
                                </div>
                            </div>
                            
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-1">{goal.name}</h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">{goal.deadline ? `Target: ${new Date(goal.deadline).toLocaleDateString()}` : 'No deadline'}</p>
                            
                            <div className="mb-4">
                                <div className="flex justify-between text-xs mb-1 font-medium">
                                    <span className={isComplete ? 'text-yellow-600 dark:text-yellow-400' : 'text-slate-600 dark:text-slate-300'}>{Math.round(progress)}% Saved</span>
                                    <span className="text-slate-900 dark:text-slate-100">₹{goal.currentAmount.toLocaleString()}</span>
                                </div>
                                <div className="w-full h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                                    <div className={`h-full rounded-full transition-all duration-1000 ${isComplete ? 'bg-yellow-400' : 'bg-indigo-600 dark:bg-indigo-500'}`} style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                        </div>

                        {!isComplete && (
                            <div className="relative z-10 pt-4 border-t border-slate-100 dark:border-slate-700">
                                <label className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider mb-2 block">Contribute</label>
                                <div className="flex space-x-2">
                                    <input 
                                        type="number" 
                                        placeholder="Amount" 
                                        className="w-24 p-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg dark:bg-slate-900 dark:text-white"
                                        value={contributeAmounts[goal.id] || ''}
                                        onChange={(e) => setContributeAmounts({...contributeAmounts, [goal.id]: e.target.value})}
                                    />
                                    <button 
                                        onClick={() => handleContributeClick(goal.id)}
                                        className="flex-1 bg-slate-800 dark:bg-slate-700 text-white rounded-lg text-sm font-medium hover:bg-slate-900 dark:hover:bg-slate-600 flex items-center justify-center"
                                    >
                                        Add <ArrowRight size={14} className="ml-1"/>
                                    </button>
                                </div>
                            </div>
                        )}
                        {isComplete && (
                            <div className="relative z-10 pt-4 border-t border-yellow-100 dark:border-yellow-900/30 text-center text-yellow-700 dark:text-yellow-300 font-bold text-sm">
                                Goal Achieved! 🎉
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    </div>
  );
};

export default Goals;
