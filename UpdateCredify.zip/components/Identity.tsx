import React from 'react';
import { UserProfile } from '../types';
import { Fingerprint, CheckCircle, Shield, QrCode, Globe, Key } from 'lucide-react';

interface IdentityProps {
  user: UserProfile;
}

const Identity: React.FC<IdentityProps> = ({ user }) => {
  return (
    <div className="animate-fade-in max-w-2xl mx-auto space-y-8">
        <div className="text-center">
             <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Blockchain Identity (DID)</h2>
             <p className="text-slate-500 dark:text-slate-400">Your decentralized, tamper-proof digital profile.</p>
        </div>

        {/* ID CARD */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-3xl p-8 shadow-2xl relative overflow-hidden border border-slate-700">
             {/* Holographic effect */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
             
             <div className="relative z-10 flex flex-col md:flex-row justify-between items-center md:items-start gap-8">
                 <div className="text-center md:text-left">
                     <div className="mb-4">
                         <p className="text-xs uppercase tracking-[0.2em] text-slate-400 mb-1">Decentralized ID</p>
                         <p className="font-mono text-sm text-emerald-400 bg-slate-900/50 px-3 py-1 rounded-lg border border-slate-700 inline-block">
                             {user.did}
                         </p>
                     </div>

                     <div className="space-y-4">
                         <div>
                            <p className="text-xs text-slate-400 uppercase">Holder Name</p>
                            <p className="text-2xl font-bold tracking-wide">{user.name}</p>
                         </div>
                         <div className="flex space-x-8">
                             <div>
                                <p className="text-xs text-slate-400 uppercase">Trust Score</p>
                                <p className="text-xl font-bold text-emerald-400">{user.trustScore}/100</p>
                             </div>
                             <div>
                                <p className="text-xs text-slate-400 uppercase">Verified Since</p>
                                <p className="text-xl font-bold">2024</p>
                             </div>
                         </div>
                     </div>
                 </div>

                 <div className="bg-white p-4 rounded-xl shadow-lg">
                     <QrCode size={100} className="text-slate-900" />
                 </div>
             </div>

             <div className="mt-8 pt-6 border-t border-white/10 flex justify-between items-center text-xs text-slate-400">
                 <div className="flex items-center space-x-2">
                     <Shield size={14} className="text-emerald-400" />
                     <span>Cryptographically Secured</span>
                 </div>
                 <div className="font-mono">
                     Hash: 8f4a...9b2c
                 </div>
             </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex flex-col items-center text-center">
                <Globe className="text-indigo-500 mb-2" size={24} />
                <h4 className="font-bold text-sm dark:text-white">Universal Login</h4>
                <p className="text-xs text-slate-500 mt-1">Use this ID to login to government portals and banks.</p>
            </div>
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex flex-col items-center text-center">
                <Key className="text-orange-500 mb-2" size={24} />
                <h4 className="font-bold text-sm dark:text-white">Self-Sovereign</h4>
                <p className="text-xs text-slate-500 mt-1">You own your data. No central authority controls it.</p>
            </div>
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex flex-col items-center text-center">
                <CheckCircle className="text-green-500 mb-2" size={24} />
                <h4 className="font-bold text-sm dark:text-white">KYC Verified</h4>
                <p className="text-xs text-slate-500 mt-1">Aadhaar/PAN hash is linked to this ID securely.</p>
            </div>
        </div>
    </div>
  );
};

export default Identity;