
import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { UserProfile, AdminStats } from '../types';
import { ShieldAlert, Users, Activity, Lock, Unlock, LogOut, Search, RefreshCw, AlertTriangle, Terminal, Cpu, HardDrive, CheckCircle } from 'lucide-react';

interface AdminDashboardProps {
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [flaggedTx, setFlaggedTx] = useState<any[]>([]);
  const [systemLogs, setSystemLogs] = useState<any[]>([]);
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 0, totalLiquidity: 0, totalTransactions: 0, flaggedTransactions: 0 });
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'fraud' | 'logs'>('overview');
  const [searchTerm, setSearchTerm] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
        const data = await api.getAdminData();
        const logs = await api.getSystemLogs();
        setUsers(data.users as UserProfile[]);
        setFlaggedTx(data.flaggedTransactions);
        setStats(data.stats);
        setSystemLogs(logs);
    } catch (e) {
        console.error("Failed to fetch admin data", e);
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleUnlockUser = async (userId: string) => {
      if (window.confirm("Are you sure you want to unlock this user's wallet?")) {
          const res = await api.adminUnlockWallet(userId);
          if (res.success) {
              alert("User Unlocked");
              fetchData();
          } else {
              alert("Failed to unlock");
          }
      }
  };

  const filteredUsers = users.filter(u => u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email?.toLowerCase().includes(searchTerm.toLowerCase()));

  if (loading) {
      return (
          <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">
              <div className="flex flex-col items-center">
                  <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                  <p>Loading Admin Panel...</p>
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex font-sans text-slate-900 dark:text-white">
        {/* Sidebar */}
        <div className="w-64 bg-slate-900 text-white flex flex-col fixed inset-y-0 shadow-2xl z-20">
            <div className="p-6 border-b border-slate-800 flex items-center space-x-2">
                <div className="bg-red-600 p-1.5 rounded-lg">
                    <ShieldAlert className="text-white" size={20} />
                </div>
                <span className="font-bold text-xl tracking-tight">Credify Admin</span>
            </div>
            
            <div className="p-6 pb-0">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Main Menu</p>
            </div>

            <nav className="flex-1 p-4 space-y-2">
                <button onClick={() => setActiveTab('overview')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'overview' ? 'bg-indigo-600 shadow-lg shadow-indigo-500/30' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <Activity size={20} />
                    <span className="font-medium">Overview</span>
                </button>
                <button onClick={() => setActiveTab('users')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'users' ? 'bg-indigo-600 shadow-lg shadow-indigo-500/30' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <Users size={20} />
                    <span className="font-medium">User Management</span>
                </button>
                <button onClick={() => setActiveTab('fraud')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'fraud' ? 'bg-indigo-600 shadow-lg shadow-indigo-500/30' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <AlertTriangle size={20} />
                    <span className="font-medium">Fraud Monitor</span>
                    {stats.flaggedTransactions > 0 && <span className="bg-red-500 text-xs px-2 py-0.5 rounded-full ml-auto font-bold">{stats.flaggedTransactions}</span>}
                </button>
                <button onClick={() => setActiveTab('logs')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'logs' ? 'bg-indigo-600 shadow-lg shadow-indigo-500/30' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <Terminal size={20} />
                    <span className="font-medium">System Logs</span>
                </button>
            </nav>
            <div className="p-4 border-t border-slate-800">
                <button onClick={onLogout} className="w-full flex items-center space-x-2 text-slate-400 hover:text-red-400 px-4 py-2 transition-colors">
                    <LogOut size={16} />
                    <span className="font-medium">Logout</span>
                </button>
            </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 ml-64 p-8 overflow-y-auto bg-slate-50 dark:bg-slate-950">
            <header className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-2xl font-bold capitalize text-slate-800 dark:text-white">{activeTab} Dashboard</h1>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Welcome back, Admin</p>
                </div>
                <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2 text-xs font-mono bg-white dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                        <span className="text-green-600 dark:text-green-400">System Online</span>
                    </div>
                    <button onClick={fetchData} className="p-2 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-slate-600 dark:text-slate-300">
                        <RefreshCw size={20} />
                    </button>
                </div>
            </header>

            {activeTab === 'overview' && (
                <div className="space-y-6">
                    {/* Stats Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 dark:bg-indigo-900/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                            <div className="flex justify-between items-start mb-4 relative z-10">
                                <div className="bg-indigo-100 dark:bg-indigo-900/30 p-3 rounded-xl">
                                    <Users className="text-indigo-600 dark:text-indigo-400" size={24} />
                                </div>
                                <span className="text-xs text-green-500 font-bold bg-green-50 dark:bg-green-900/30 px-2 py-1 rounded">+12%</span>
                            </div>
                            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Total Users</p>
                            <p className="text-3xl font-bold mt-1 text-slate-800 dark:text-white">{stats.totalUsers}</p>
                        </div>
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 dark:bg-emerald-900/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                            <div className="flex justify-between items-start mb-4 relative z-10">
                                <div className="bg-emerald-100 dark:bg-emerald-900/30 p-3 rounded-xl">
                                    <Activity className="text-emerald-600 dark:text-emerald-400" size={24} />
                                </div>
                            </div>
                            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Total Liquidity</p>
                            <p className="text-3xl font-bold mt-1 text-slate-800 dark:text-white">₹{stats.totalLiquidity.toLocaleString()}</p>
                        </div>
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 dark:bg-blue-900/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                            <div className="flex justify-between items-start mb-4 relative z-10">
                                <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-xl">
                                    <RefreshCw className="text-blue-600 dark:text-blue-400" size={24} />
                                </div>
                            </div>
                            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Transactions</p>
                            <p className="text-3xl font-bold mt-1 text-slate-800 dark:text-white">{stats.totalTransactions}</p>
                        </div>
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-red-50 dark:bg-red-900/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
                            <div className="flex justify-between items-start mb-4 relative z-10">
                                <div className="bg-red-100 dark:bg-red-900/30 p-3 rounded-xl">
                                    <AlertTriangle className="text-red-600 dark:text-red-400" size={24} />
                                </div>
                            </div>
                            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Flagged Fraud</p>
                            <p className="text-3xl font-bold mt-1 text-red-500">{stats.flaggedTransactions}</p>
                        </div>
                    </div>

                    {/* System Health */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
                            <h3 className="font-bold text-slate-800 dark:text-white mb-4 flex items-center">
                                <Cpu size={20} className="mr-2 text-indigo-500" /> System Load (Simulated)
                            </h3>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between text-xs font-medium mb-1 text-slate-500 dark:text-slate-400">
                                        <span>CPU Usage</span>
                                        <span>32%</span>
                                    </div>
                                    <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-2">
                                        <div className="bg-indigo-500 h-2 rounded-full" style={{ width: '32%' }}></div>
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between text-xs font-medium mb-1 text-slate-500 dark:text-slate-400">
                                        <span>Memory Usage</span>
                                        <span>64%</span>
                                    </div>
                                    <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-2">
                                        <div className="bg-purple-500 h-2 rounded-full" style={{ width: '64%' }}></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
                             <h3 className="font-bold text-slate-800 dark:text-white mb-4 flex items-center">
                                <HardDrive size={20} className="mr-2 text-emerald-500" /> Database Status
                            </h3>
                            <div className="flex items-center justify-between p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl mb-3">
                                <div className="flex items-center space-x-3">
                                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                                    <span className="text-sm font-medium text-emerald-700 dark:text-emerald-400">MongoDB Cluster</span>
                                </div>
                                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">Connected</span>
                            </div>
                            <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mt-2">
                                <span>Requests/sec: 450</span>
                                <span>Latency: 24ms</span>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'users' && (
                <div className="space-y-4">
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center space-x-2">
                        <Search className="text-slate-400" size={20} />
                        <input 
                            type="text" 
                            placeholder="Search users by name or email..." 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="bg-transparent flex-1 outline-none text-slate-800 dark:text-white placeholder-slate-400"
                        />
                    </div>
                    
                    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden">
                        <table className="w-full text-left">
                            <thead className="bg-slate-50 dark:bg-slate-900 text-xs text-slate-500 dark:text-slate-400 uppercase border-b border-slate-100 dark:border-slate-700">
                                <tr>
                                    <th className="p-4">User</th>
                                    <th className="p-4">Balance</th>
                                    <th className="p-4">Status</th>
                                    <th className="p-4">Trust Score</th>
                                    <th className="p-4 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                                {filteredUsers.map((u, i) => (
                                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                                        <td className="p-4">
                                            <p className="font-bold text-slate-800 dark:text-white text-sm">{u.name}</p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">{u.email}</p>
                                        </td>
                                        <td className="p-4 font-mono text-sm text-slate-700 dark:text-slate-300">₹{u.balance.toLocaleString()}</td>
                                        <td className="p-4">
                                            {u.isWalletLocked ? (
                                                <span className="bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-xs px-2 py-1 rounded-full font-bold flex items-center w-fit">
                                                    <Lock size={10} className="mr-1"/> Locked
                                                </span>
                                            ) : (
                                                <span className="bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 text-xs px-2 py-1 rounded-full font-bold flex items-center w-fit">
                                                    <CheckCircle size={10} className="mr-1"/> Active
                                                </span>
                                            )}
                                        </td>
                                        <td className="p-4">
                                            <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-1.5 w-24">
                                                <div className={`h-1.5 rounded-full ${u.trustScore > 80 ? 'bg-green-500' : 'bg-yellow-500'}`} style={{ width: `${u.trustScore}%` }}></div>
                                            </div>
                                            <span className="text-xs text-slate-500 mt-1 block">{u.trustScore}/100</span>
                                        </td>
                                        <td className="p-4 text-right">
                                            {u.isWalletLocked && (
                                                <button 
                                                    onClick={() => handleUnlockUser(u.id || '')}
                                                    className="text-xs bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-900/30 dark:hover:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                                >
                                                    <Unlock size={14} className="inline mr-1" /> Unlock
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'fraud' && (
                <div className="space-y-4">
                     {flaggedTx.length === 0 ? (
                         <div className="text-center py-20 bg-white dark:bg-slate-800 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
                             <CheckCircle size={48} className="text-green-500 mx-auto mb-4 opacity-50" />
                             <p className="text-slate-500 dark:text-slate-400 font-medium">No suspicious transactions detected.</p>
                         </div>
                     ) : (
                         <div className="grid grid-cols-1 gap-4">
                             {flaggedTx.map((tx, idx) => (
                                 <div key={idx} className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-red-100 dark:border-red-900/50 shadow-sm flex items-start justify-between">
                                     <div className="flex items-start space-x-4">
                                         <div className="bg-red-100 dark:bg-red-900/30 p-3 rounded-xl">
                                             <AlertTriangle className="text-red-600 dark:text-red-400" size={24} />
                                         </div>
                                         <div>
                                             <h4 className="font-bold text-slate-800 dark:text-white">Suspicious Activity Detected</h4>
                                             <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                                                 User: <span className="font-bold">{tx.userName || 'Unknown'}</span> • Amount: <span className="font-bold text-red-500">₹{tx.amount}</span>
                                             </p>
                                             <div className="mt-2 bg-red-50 dark:bg-red-900/20 px-3 py-1.5 rounded-lg border border-red-100 dark:border-red-800 inline-block">
                                                 <p className="text-xs text-red-700 dark:text-red-300 font-mono">Reason: {tx.fraudReason}</p>
                                             </div>
                                         </div>
                                     </div>
                                     <div className="text-right text-xs text-slate-400">
                                         {new Date(tx.date).toLocaleString()}
                                     </div>
                                 </div>
                             ))}
                         </div>
                     )}
                </div>
            )}

            {activeTab === 'logs' && (
                <div className="bg-slate-900 text-slate-300 p-6 rounded-2xl font-mono text-xs shadow-inner h-[500px] overflow-y-auto custom-scrollbar border border-slate-800">
                    {systemLogs.map((log, i) => (
                        <div key={i} className="mb-2 flex space-x-3 hover:bg-slate-800/50 p-1 rounded">
                            <span className="text-slate-500 shrink-0">[{new Date(log.time).toLocaleTimeString()}]</span>
                            <span className={`font-bold uppercase shrink-0 w-16 ${
                                log.type === 'ERROR' ? 'text-red-500' : 
                                log.type === 'WARN' ? 'text-yellow-500' : 
                                log.type === 'SUCCESS' ? 'text-green-500' : 'text-blue-500'
                            }`}>{log.type}</span>
                            <span className="text-slate-300">{log.msg}</span>
                        </div>
                    ))}
                    <div className="flex items-center space-x-2 mt-4 animate-pulse">
                        <span className="text-green-500">➜</span>
                        <span className="w-2 h-4 bg-slate-500"></span>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default AdminDashboard;
