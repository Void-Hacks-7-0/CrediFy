
import React, { useState } from 'react';
import { Block, TransactionType, Category, UserProfile, Language, Contact, TransactionRequest } from '../types';
import { ShieldCheck, Send, Clock, Hash, Smartphone, PiggyBank, Lock, Coins, CreditCard, LockKeyhole, Eye, EyeOff, PlusCircle, Repeat } from 'lucide-react';
import { t } from '../services/translations';

interface WalletProps {
  chain: Block[];
  onTransactionRequest: (req: TransactionRequest) => void;
  user: UserProfile;
  lang: Language;
}

// Mock Community Data
const MOCK_CONTACTS: Contact[] = Array.from({ length: 15 }).map((_, i) => ({
    id: `u${i + 1}`,
    name: ['Aarav', 'Vihaan', 'Aditya', 'Sai', 'Reyansh', 'Diya', 'Ananya', 'Saanvi', 'Kiara', 'Myra'][i % 10] + (i > 9 ? ` ${i}` : ''),
    mobile: `9876${500000 + i}`,
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`,
    trustScore: 80 + (i % 20)
}));

const Wallet: React.FC<WalletProps> = ({ chain, onTransactionRequest, user, lang }) => {
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [sending, setSending] = useState(false);
  const [showChain, setShowChain] = useState(false);
  const [showEncrypted, setShowEncrypted] = useState(true);
  
  // Currency State
  const [transferCurrency, setTransferCurrency] = useState<'INR' | 'SRC'>('INR');

  // Payment Gateway State
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [addAmount, setAddAmount] = useState('');
  const [processingPayment, setProcessingPayment] = useState(false);

  const handleSend = () => {
    if (!amount || !recipient) return;
    setSending(true);
    
    // Simulate brief delay before opening PIN modal
    setTimeout(() => {
      onTransactionRequest({
          amount: parseFloat(amount),
          category: Category.OTHER,
          description: `Transfer to ${recipient} (${transferCurrency})`,
          type: TransactionType.TRANSFER,
          currency: transferCurrency
      });
      setSending(false);
      setAmount('');
      setRecipient('');
    }, 500);
  };

  const handleAddMoney = () => {
      if(!addAmount) return;
      onTransactionRequest({
          amount: parseFloat(addAmount),
          category: Category.OTHER,
          description: `Wallet Top-up via UPI`,
          type: TransactionType.INCOME,
          currency: 'INR'
      });
      setShowPaymentModal(false);
      setAddAmount('');
  }

  return (
    <div className="space-y-6">
      
      {/* Payment Modal */}
      {showPaymentModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 w-full max-w-md m-4 shadow-2xl relative">
                  <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center">
                      <CreditCard className="mr-2 text-indigo-600" />
                      {t(lang, 'addMoney')}
                  </h3>
                  
                  {processingPayment ? (
                       <div className="flex flex-col items-center justify-center py-8">
                           <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
                           <p className="text-slate-600 dark:text-slate-300 font-medium">Processing...</p>
                       </div>
                  ) : (
                      <>
                        <div className="mb-4">
                            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">{t(lang, 'amount')}</label>
                            <input 
                                type="number" 
                                value={addAmount}
                                onChange={(e) => setAddAmount(e.target.value)}
                                className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                                placeholder="1000"
                            />
                        </div>
                        <div className="flex space-x-3">
                            <button onClick={() => setShowPaymentModal(false)} className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400">Cancel</button>
                            <button onClick={handleAddMoney} className="flex-1 py-2.5 rounded-xl bg-indigo-600 text-white font-medium hover:bg-indigo-700">{t(lang, 'payNow')}</button>
                        </div>
                      </>
                  )}
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Wallet Card */}
        <div className="md:col-span-2 bg-slate-900 dark:bg-black text-white p-6 rounded-2xl shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[220px]">
            <div className="relative z-10">
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-slate-400 text-sm font-medium uppercase tracking-wider">{t(lang, 'totalLiquidity')}</h2>
                        <div className="flex items-baseline space-x-2 mt-2">
                            <span className="text-4xl font-extrabold text-white">₹{(user.balance + user.lockedBalance).toLocaleString()}</span>
                        </div>
                    </div>
                    <button onClick={() => setShowPaymentModal(true)} className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-medium flex items-center shadow-lg transition-transform active:scale-95">
                        <PlusCircle className="w-4 h-4 mr-1" />
                        {t(lang, 'addMoney')}
                    </button>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-8">
                     <div>
                         <p className="text-xs text-slate-400 mb-1">{t(lang, 'available')}</p>
                         <p className="font-bold text-emerald-400">₹{user.balance.toLocaleString()}</p>
                     </div>
                     <div>
                         <p className="text-xs text-slate-400 mb-1 flex items-center"><Lock size={10} className="mr-1"/> {t(lang, 'locked')}</p>
                         <p className="font-bold text-yellow-400">₹{user.lockedBalance.toLocaleString()}</p>
                     </div>
                </div>
            </div>
             <div className="absolute right-0 top-0 h-full w-1/2 bg-emerald-500/10 rounded-full blur-3xl transform translate-x-12 -translate-y-12"></div>
        </div>

        {/* Rewards */}
        <div className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white p-6 rounded-2xl shadow-xl relative overflow-hidden flex flex-col justify-center text-center">
             <div className="relative z-10 flex flex-col items-center">
                <div className="bg-white/20 p-3 rounded-full mb-3 backdrop-blur-md">
                    <Coins size={28} className="text-yellow-300" />
                </div>
                <h2 className="text-indigo-100 text-sm font-medium">{t(lang, 'rewards')}</h2>
                <div className="flex items-baseline space-x-1 mt-1">
                    <span className="text-3xl font-extrabold text-white">{user.tokenBalance}</span>
                    <span className="text-sm font-bold text-indigo-200">SRC</span>
                </div>
                <button onClick={() => alert("Redemption Successful!")} className="mt-4 text-xs bg-white text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-lg transition-colors font-bold shadow-md active:scale-95">
                    {t(lang, 'redeem')}
                </button>
             </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Transfer Section */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-slate-800 dark:text-white flex items-center">
                <Send size={20} className="mr-2 text-indigo-600 dark:text-indigo-400" />
                {t(lang, 'transfer')}
            </h3>
            
            {/* Currency Toggle */}
            <div className="flex bg-slate-100 dark:bg-slate-900 rounded-lg p-1">
                <button 
                    onClick={() => setTransferCurrency('INR')}
                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${transferCurrency === 'INR' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-white' : 'text-slate-500'}`}
                >
                    ₹ INR
                </button>
                <button 
                    onClick={() => setTransferCurrency('SRC')}
                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${transferCurrency === 'SRC' ? 'bg-white dark:bg-slate-700 shadow-sm text-purple-600 dark:text-purple-300' : 'text-slate-500'}`}
                >
                    SRC
                </button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">{t(lang, 'recipient')}</label>
              <input 
                type="text" 
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder="e.g. 98765xxxxx"
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white transition-all"
              />
            </div>

            {/* Quick Contacts List - Mock Scalability */}
            <div>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">{t(lang, 'quickContacts')}</p>
                <div className="flex space-x-3 overflow-x-auto no-scrollbar pb-2">
                    {MOCK_CONTACTS.map(contact => (
                        <div 
                            key={contact.id} 
                            onClick={() => setRecipient(contact.mobile)}
                            className="flex flex-col items-center flex-shrink-0 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 p-2 rounded-lg transition-colors"
                        >
                            <img src={contact.avatar} alt={contact.name} className="w-10 h-10 rounded-full mb-1 border-2 border-slate-200 dark:border-slate-600" />
                            <span className="text-[10px] font-medium text-slate-700 dark:text-slate-300">{contact.name}</span>
                        </div>
                    ))}
                </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                  {t(lang, 'amount')} ({transferCurrency})
              </label>
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white transition-all"
              />
              {transferCurrency === 'SRC' && (
                  <p className="text-[10px] text-purple-600 mt-1">Balance: {user.tokenBalance} SRC</p>
              )}
            </div>
            
            <button 
              onClick={handleSend}
              disabled={sending || !amount || !recipient}
              className={`w-full py-3 rounded-xl flex items-center justify-center space-x-2 font-medium text-white transition-all
                ${sending ? 'bg-indigo-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95 shadow-md hover:shadow-lg'}
              `}
            >
              {sending ? (
                 <span>Initializing Secure Flow...</span>
              ) : (
                <>
                  <span>{t(lang, 'sendSecurely')}</span>
                  <Send size={16} />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Ledger Visualizer */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-slate-800 dark:text-white flex items-center">
                    <Hash size={20} className="mr-2 text-indigo-600 dark:text-indigo-400" />
                    {t(lang, 'liveLedger')}
                </h3>
                <div className="flex space-x-3">
                     <button onClick={() => setShowEncrypted(!showEncrypted)} className="text-xs text-slate-500 hover:text-indigo-600 dark:text-slate-400 flex items-center">
                        {showEncrypted ? <EyeOff size={14} className="mr-1"/> : <Eye size={14} className="mr-1"/>}
                        {showEncrypted ? 'Show Decrypted' : 'Show Encrypted'}
                    </button>
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto max-h-[300px] space-y-3 no-scrollbar pr-2">
                {chain.slice().reverse().map((block) => (
                    <div key={block.hash} className="group relative pl-4 border-l-2 border-slate-200 dark:border-slate-700 last:border-transparent pb-4">
                         <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white dark:bg-slate-800 border-2 border-indigo-500 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/50"></div>
                         <div className="bg-slate-50 dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-700 group-hover:border-indigo-200 dark:group-hover:border-indigo-800 transition-colors">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Block #{block.index}</span>
                                <span className="text-[10px] text-slate-400 flex items-center">
                                    <Clock size={10} className="mr-1" />
                                    {new Date(block.timestamp).toLocaleTimeString()}
                                </span>
                            </div>
                            
                            <div className="text-xs text-slate-600 dark:text-slate-400 mb-1 font-mono break-all">
                                {showEncrypted && block.encryptedData ? (
                                    <span className="text-indigo-500 flex items-center">
                                        <LockKeyhole size={10} className="mr-1 inline" />
                                        {block.encryptedData.substring(0, 40)}...
                                    </span>
                                ) : (
                                    <span>
                                        <span className="font-bold">
                                            {block.data.type} 
                                            {block.data.currency === 'SRC' ? ' (CRYPTO)' : ''}:
                                        </span> 
                                        {block.data.currency === 'SRC' ? '' : ' ₹'}{block.data.amount}{block.data.currency === 'SRC' ? ' SRC' : ''} ({block.data.description})
                                    </span>
                                )}
                            </div>
                         </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default Wallet;
