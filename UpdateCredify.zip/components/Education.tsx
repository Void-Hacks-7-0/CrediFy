
import React, { useEffect, useState } from 'react';
import { getFinancialAdvice, getFinancialQuiz } from '../services/geminiService';
import { Transaction, UserProfile, Language } from '../types';
import { Lightbulb, BookOpen, GraduationCap, CheckCircle, RefreshCcw, Mic, Volume2, TrendingUp, PieChart, Landmark } from 'lucide-react';
import { t } from '../services/translations';

interface EducationProps {
  transactions: Transaction[];
  user: UserProfile;
  lang: Language;
}

const Education: React.FC<EducationProps> = ({ transactions, user, lang }) => {
  const [advice, setAdvice] = useState<string>('Analyzing your spending patterns...');
  const [quiz, setQuiz] = useState<{ question: string; options: string[]; answer: string } | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingQuiz, setLoadingQuiz] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [voiceQuery, setVoiceQuery] = useState('');

  const fetchAdvice = async () => {
    setLoading(true);
    const result = await getFinancialAdvice(transactions, user.budgetLimit);
    setAdvice(result);
    setLoading(false);
  };

  const fetchQuiz = async () => {
      setLoadingQuiz(true);
      setSelectedOption(null);
      const q = await getFinancialQuiz();
      setQuiz(q);
      setLoadingQuiz(false);
  }

  useEffect(() => {
    fetchAdvice();
    fetchQuiz();
  }, []);

  const handleQuizAnswer = (option: string) => {
      if (selectedOption) return;
      setSelectedOption(option);
  };

  const handleVoiceSimulate = () => {
      if (voiceMode) {
          setVoiceMode(false);
          return;
      }
      setVoiceMode(true);
      setVoiceQuery(t(lang, 'listening'));
      setTimeout(() => {
          setVoiceQuery("Mujhe SIP ke baare mein batao (Tell me about SIP)");
          setTimeout(() => {
             setAdvice("SIP (Systematic Investment Plan) ek tarika hai jisme aap har mahine thoda paisa Mutual Funds mein daal sakte hain.");
             setVoiceQuery("");
             setVoiceMode(false);
          }, 2000);
      }, 1500);
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      
      {/* AI Financial Advisor */}
      <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Lightbulb size={120} />
        </div>
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
             <h2 className="text-xl font-bold flex items-center">
                <div className="bg-white/20 p-2 rounded-lg mr-3">
                   <Lightbulb size={24} className="text-yellow-300" />
                </div>
                {t(lang, 'aiTutor')}
             </h2>
             <div className="flex space-x-2">
                <button onClick={handleVoiceSimulate} className={`text-xs p-2 rounded-full transition-colors flex items-center ${voiceMode ? 'bg-red-500 animate-pulse' : 'bg-white/10 hover:bg-white/20'}`}>
                    {voiceMode ? <Mic size={14} className="mr-1"/> : <Mic size={14} />}
                    {voiceMode && "Listening"}
                </button>
                <button onClick={fetchAdvice} disabled={loading} className="text-xs bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors">
                    <RefreshCcw size={14} className={loading ? "animate-spin" : ""} />
                </button>
             </div>
          </div>

          {voiceQuery && (
              <div className="mb-3 text-sm italic opacity-80 bg-black/20 p-2 rounded-lg">
                  "{voiceQuery}"
              </div>
          )}
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 min-h-[150px] text-sm leading-relaxed border border-white/10">
            {loading ? (
                <div className="flex flex-col items-center justify-center h-32 space-y-2">
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span className="text-xs opacity-70">Thinking...</span>
                </div>
            ) : (
                <div className="whitespace-pre-wrap">
                    {advice}
                </div>
            )}
          </div>
          
          <div className="mt-4 flex items-center justify-between text-xs opacity-70">
            <span>Powered by Gemini 2.5</span>
            <span className="flex items-center"><Volume2 size={10} className="mr-1"/> {lang === 'hi' ? 'हिंदी समर्थित' : 'Supports Hindi'}</span>
          </div>
        </div>
      </div>

      {/* Quiz Section */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold text-slate-800 dark:text-white flex items-center">
                <GraduationCap className="mr-2 text-indigo-600 dark:text-indigo-400" />
                {t(lang, 'quiz')}
            </h2>
             <button onClick={fetchQuiz} disabled={loadingQuiz} className="text-xs text-indigo-600 dark:text-indigo-400 font-medium hover:underline">
                 Next
             </button>
          </div>

          {loadingQuiz || !quiz ? (
              <div className="flex-1 flex items-center justify-center">
                  <div className="w-8 h-8 border-4 border-indigo-100 dark:border-slate-700 border-t-indigo-600 dark:border-t-indigo-400 rounded-full animate-spin"></div>
              </div>
          ) : (
              <div className="flex-1 flex flex-col justify-between">
                  <div>
                      <h3 className="text-md font-medium text-slate-700 dark:text-slate-300 mb-4">{quiz.question}</h3>
                      <div className="space-y-2">
                          {quiz.options.map((opt, idx) => {
                              const isSelected = selectedOption === opt;
                              const isCorrect = opt === quiz.answer;
                              let btnClass = "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500 dark:text-slate-300";
                              
                              if (selectedOption) {
                                  if (isCorrect) btnClass = "bg-green-50 dark:bg-green-900/30 border-green-500 text-green-700 dark:text-green-300";
                                  else if (isSelected) btnClass = "bg-red-50 dark:bg-red-900/30 border-red-500 text-red-700 dark:text-red-300";
                                  else btnClass = "border-slate-100 dark:border-slate-800 opacity-50 dark:text-slate-500";
                              }

                              return (
                                  <button
                                    key={idx}
                                    onClick={() => handleQuizAnswer(opt)}
                                    disabled={!!selectedOption}
                                    className={`w-full text-left p-3 rounded-xl border text-sm font-medium transition-all ${btnClass}`}
                                  >
                                      <div className="flex justify-between items-center">
                                          <span>{opt}</span>
                                          {selectedOption && isCorrect && <CheckCircle size={16} className="text-green-600 dark:text-green-400"/>}
                                      </div>
                                  </button>
                              )
                          })}
                      </div>
                  </div>
                  {selectedOption && (
                      <div className={`mt-4 p-3 rounded-lg text-xs font-medium text-center ${selectedOption === quiz.answer ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-200'}`}>
                          {selectedOption === quiz.answer ? "+10 SecureCoins!" : "Incorrect"}
                      </div>
                  )}
              </div>
          )}
      </div>

      {/* Investment Basics (NEW) */}
      <div className="md:col-span-2 mt-2">
          <h3 className="font-semibold text-slate-800 dark:text-white mb-3 flex items-center">
             <TrendingUp className="mr-2 text-slate-500 dark:text-slate-400" size={18} />
             {t(lang, 'investmentBasics')}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-indigo-50 dark:bg-indigo-900/20 p-5 rounded-xl border border-indigo-100 dark:border-indigo-800 hover:shadow-md transition-shadow">
                  <div className="flex items-center mb-2">
                      <div className="p-2 bg-indigo-100 dark:bg-indigo-900/50 rounded-lg mr-3">
                          <PieChart size={20} className="text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <h4 className="font-bold text-slate-800 dark:text-white">Mutual Funds</h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {lang === 'hi' ? 'म्यूचुअल फंड कई निवेशकों से पैसा इकट्ठा करके स्टॉक और बॉन्ड में निवेश करता है।' : 'Pools money from many investors to purchase stocks. Start with ₹500/month.'}
                  </p>
              </div>
              
              <div className="bg-purple-50 dark:bg-purple-900/20 p-5 rounded-xl border border-purple-100 dark:border-purple-800 hover:shadow-md transition-shadow">
                  <div className="flex items-center mb-2">
                      <div className="p-2 bg-purple-100 dark:bg-purple-900/50 rounded-lg mr-3">
                          <TrendingUp size={20} className="text-purple-600 dark:text-purple-400" />
                      </div>
                      <h4 className="font-bold text-slate-800 dark:text-white">SIP</h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {lang === 'hi' ? 'SIP आपको नियमित रूप से (जैसे मासिक) छोटी राशि निवेश करने की अनुमति देता है।' : 'Systematic Investment Plan: Invest fixed amounts regularly to reduce market risk.'}
                  </p>
              </div>

               {/* New Govt Schemes Section */}
               <div className="bg-emerald-50 dark:bg-emerald-900/20 p-5 rounded-xl border border-emerald-100 dark:border-emerald-800 hover:shadow-md transition-shadow">
                  <div className="flex items-center mb-2">
                      <div className="p-2 bg-emerald-100 dark:bg-emerald-900/50 rounded-lg mr-3">
                          <Landmark size={20} className="text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <h4 className="font-bold text-slate-800 dark:text-white">{t(lang, 'govtSchemes')}</h4>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {lang === 'hi' ? 'पीएम जन धन योजना: शून्य शेष राशि खाता और बीमा कवरेज।' : 'PMJDY (Zero Balance Account) & APY (Pension for unorganized sector).'}
                  </p>
              </div>
          </div>
      </div>
    </div>
  );
};

export default Education;
