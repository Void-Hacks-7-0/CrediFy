
import React, { useState } from 'react';
import { Transaction, Category, TransactionType, Language, TransactionRequest } from '../types';
import { PlusCircle, Search, AlertCircle, ShoppingBag, Coffee, BookOpen, Bus, Activity, Zap, CreditCard, HelpCircle, Users, PiggyBank, Download, Check, FileText, Mic, Loader2 } from 'lucide-react';
import { t } from '../services/translations';

interface ExpensesProps {
  transactions: Transaction[];
  onTransactionRequest: (req: TransactionRequest) => void;
  lang: Language;
}

const Expenses: React.FC<ExpensesProps> = ({ transactions, onTransactionRequest, lang }) => {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>(Category.FOOD);
  const [description, setDescription] = useState('');
  const [search, setSearch] = useState('');
  
  // Voice Input State
  const [isListening, setIsListening] = useState(false);
  const [voiceHint, setVoiceHint] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;
    onTransactionRequest({
        amount: parseFloat(amount),
        category,
        description,
        type: TransactionType.EXPENSE
    });
    setAmount('');
    setDescription('');
  };

  const handleVoiceInput = () => {
    if (isListening) {
        setIsListening(false);
        return;
    }
    
    setIsListening(true);
    setVoiceHint(t(lang, 'listening'));
    
    // Simulate Voice Processing Delay and Mock Parsing
    setTimeout(() => {
        // Mock result: "Spent 100 on Food"
        // In a real app, use Web Speech API here
        setAmount('100');
        setCategory(Category.FOOD);
        setDescription('Lunch (Voice Entry)');
        setIsListening(false);
        setVoiceHint('');
    }, 2500);
  };

  const handleExport = () => {
    const headers = ['ID,Date,Description,Category,Amount,Type,Hash'];
    const rows = transactions.map(t => 
        `${t.id},${t.date},"${t.description}",${t.category},${t.amount},${t.type},${t.hash || ''}`
    );
    const csvContent = "data:text/csv;charset=utf-8," + headers.concat(rows).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "credify_transactions.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getCategoryIcon = (cat: string) => {
      switch(cat) {
          case Category.FOOD: return <Coffee size={16} />;
          case Category.EDUCATION: return <BookOpen size={16} />;
          case Category.TRAVEL: return <Bus size={16} />;
          case Category.HEALTH: return <Activity size={16} />;
          case Category.BILLS: return <Zap size={16} />;
          case Category.ENTERTAINMENT: return <ShoppingBag size={16} />;
          case Category.FAMILY: return <Users size={16} />;
          case Category.SAVINGS: return <PiggyBank size={16} />;
          case Category.CONTRACT: return <FileText size={16} />;
          default: return <HelpCircle size={16} />;
      }
  };

  const filteredTransactions = transactions.filter(t => 
    t.description.toLowerCase().includes(search.toLowerCase()) || 
    t.category.toLowerCase().includes(search.toLowerCase())
  ).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Add Expense Form */}
      <div className="lg:col-span-1">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 sticky top-4">
          <div className="flex justify-between items-center mb-4">
             <h2 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center">
                 <PlusCircle className="mr-2 text-indigo-600 dark:text-indigo-400" />
                 {t(lang, 'addExpense')}
             </h2>
             <button 
                onClick={handleVoiceInput}
                className={`p-2 rounded-full transition-all flex items-center space-x-2 text-xs font-bold ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'}`}
             >
                 {isListening ? <Loader2 size={16} className="animate-spin" /> : <Mic size={16} />}
                 <span>{isListening ? '...' : t(lang, 'voiceInput')}</span>
             </button>
          </div>
          
          {isListening && (
              <div className="mb-4 p-3 bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800 rounded-xl text-center">
                  <p className="text-sm font-medium text-indigo-700 dark:text-indigo-300">{voiceHint}</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">{t(lang, 'voiceTip')}</p>
              </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">{t(lang, 'amount')}</label>
              <input 
                type="number" 
                value={amount} 
                onChange={e => setAmount(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:text-white"
                placeholder="0.00"
              />
            </div>
            
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">{t(lang, 'category')}</label>
              <div className="grid grid-cols-2 gap-2">
                 {Object.values(Category).filter(c => c !== Category.SAVINGS && c !== Category.CONTRACT).map((cat) => (
                     <button
                        key={cat}
                        type="button"
                        onClick={() => setCategory(cat)}
                        className={`text-xs p-2 rounded-lg border text-left flex items-center space-x-2 transition-all
                            ${category === cat 
                                ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-500 text-indigo-700 dark:text-indigo-300 font-medium' 
                                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'}
                        `}
                     >
                        {getCategoryIcon(cat)}
                        <span className="truncate">{cat}</span>
                     </button>
                 ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">{t(lang, 'description')}</label>
              <input 
                type="text" 
                value={description} 
                onChange={e => setDescription(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:text-white"
                placeholder="e.g. Lunch at canteen"
              />
            </div>

            <button type="submit" className="w-full bg-indigo-600 text-white py-3 rounded-xl font-medium hover:bg-indigo-700 active:scale-95 transition-transform shadow-md">
                Verify & Add
            </button>
          </form>
        </div>
      </div>

      {/* Transaction List */}
      <div className="lg:col-span-2 space-y-4">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center space-x-2 flex-1">
                <Search className="text-slate-400" size={20} />
                <input 
                    type="text" 
                    placeholder={t(lang, 'searchTx')}
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    className="bg-transparent flex-1 outline-none text-slate-700 dark:text-slate-200 placeholder-slate-400"
                />
            </div>
            <button onClick={handleExport} className="text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center space-x-1 text-xs px-3 py-1.5 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors">
                <Download size={14} />
                <span className="hidden sm:inline">{t(lang, 'exportCsv')}</span>
            </button>
        </div>

        <div className="space-y-3 pb-20">
            {filteredTransactions.map((t) => (
                <div key={t.id} className={`bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border ${t.isSuspicious ? 'border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-900/10' : 'border-slate-100 dark:border-slate-700'} flex items-center justify-between group hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors`}>
                    <div className="flex items-center space-x-4">
                        <div className={`p-3 rounded-full ${
                            t.type === TransactionType.INCOME ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' : 
                            t.type === TransactionType.SAVINGS ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' :
                            'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400'
                        }`}>
                            {t.type === TransactionType.TRANSFER ? <CreditCard size={20}/> : getCategoryIcon(t.category)}
                        </div>
                        <div>
                            <div className="flex items-center space-x-2">
                                <h4 className="font-medium text-slate-800 dark:text-slate-200">{t.description}</h4>
                                {t.isVerified && (
                                    <span className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-[10px] px-1.5 py-0.5 rounded flex items-center">
                                        <Check size={8} className="mr-0.5" /> Verified
                                    </span>
                                )}
                            </div>
                            <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400">
                                <span>{new Date(t.date).toLocaleDateString()}</span>
                                <span className="w-1 h-1 bg-slate-300 dark:bg-slate-600 rounded-full"></span>
                                {t.type === TransactionType.SAVINGS ? (
                                    <span className="text-emerald-600 dark:text-emerald-400 font-medium">Auto-Saved</span>
                                ) : (
                                    <span className="flex items-center text-slate-400 dark:text-slate-500 font-mono">
                                        Hash: {t.hash ? t.hash.substring(0, 8) : 'Pending...'}
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className={`font-bold ${
                            t.type === TransactionType.INCOME || t.type === TransactionType.SAVINGS || t.type === TransactionType.CONTRACT_UNLOCK ? 'text-green-600 dark:text-green-400' : 'text-slate-800 dark:text-slate-200'
                        }`}>
                            {t.type === TransactionType.INCOME || t.type === TransactionType.SAVINGS || t.type === TransactionType.CONTRACT_UNLOCK ? '+' : '-'}₹{t.amount.toLocaleString()}
                        </p>
                        {t.isSuspicious && (
                            <div className="flex items-center justify-end text-[10px] text-red-500 font-bold mt-1">
                                <AlertCircle size={10} className="mr-1" />
                                Suspicious
                            </div>
                        )}
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Expenses;
