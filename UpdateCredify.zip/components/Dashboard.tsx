
import React, { useMemo, useState, useEffect } from 'react';
import { Transaction, TransactionType, UserProfile, Bill, Language, Category, BankAccount, TransactionRequest } from '../types';
import { IndianRupee, TrendingUp, TrendingDown, AlertTriangle, Zap, Calendar, CheckCircle, Sparkles, PieChart, BarChart3, QrCode, Smartphone, Landmark, Repeat, Tv, Wifi, Car, SmartphoneCharging, History, ArrowRightLeft, CreditCard, X, PlusCircle, Building, User, ScanLine, Wallet } from 'lucide-react';
import { getBudgetInsight } from '../services/geminiService';
import { t } from '../services/translations';

interface DashboardProps {
  transactions: Transaction[];
  user: UserProfile;
  bills: Bill[];
  onPayBill: (id: string) => void;
  lang: Language;
  onTransactionRequest: (req: TransactionRequest, onSuccess?: () => void) => void;
  onAddBank: (bank: BankAccount) => void;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#64748b'];

interface ModalContainerProps {
  children?: React.ReactNode;
  title: string;
  onClose: () => void;
}

const ModalContainer = ({ children, title, onClose }: ModalContainerProps) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 w-full max-w-sm shadow-2xl relative border border-slate-200 dark:border-slate-800">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center">
                    {title}
                </h3>
                <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    <X size={20} />
                </button>
            </div>
            {children}
        </div>
    </div>
);

const Dashboard: React.FC<DashboardProps> = ({ transactions, user, bills, onPayBill, lang, onTransactionRequest, onAddBank }) => {
  const [aiTip, setAiTip] = useState<string>('');
  const [loadingTip, setLoadingTip] = useState(false);
  
  // -- MODAL STATE --
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [modalData, setModalData] = useState<any>(null); // To store temp form data
  
  // Form States for Modals
  const [amount, setAmount] = useState('');
  const [identifier, setIdentifier] = useState(''); // Mobile/Account No
  const [description, setDescription] = useState('');
  const [selectedBankId, setSelectedBankId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [scanStep, setScanStep] = useState<'SCAN' | 'PAY'>('SCAN');

  // New Bank Form State
  const [newBankName, setNewBankName] = useState('');
  const [newBankAcc, setNewBankAcc] = useState('');
  const [newBankIfsc, setNewBankIfsc] = useState('');
  const [beneficiaryName, setBeneficiaryName] = useState('');

  const stats = useMemo(() => {
    const totalSpent = transactions
      .filter(t => t.type === TransactionType.EXPENSE || t.type === TransactionType.TRANSFER)
      .reduce((acc, curr) => acc + curr.amount, 0);
    
    const suspiciousCount = transactions.filter(t => t.isSuspicious).length;

    // Financial Health Score Calculation (Mock)
    let score = 80;
    score -= suspiciousCount * 10;
    if (totalSpent > user.budgetLimit) score -= 20;
    score = Math.min(100, Math.max(0, score));

    const healthColor = score > 70 ? 'text-green-500' : score > 40 ? 'text-yellow-500' : 'text-red-500';
    const healthLabel = score > 70 ? (lang === 'hi' ? 'उत्तम' : 'Excellent') : score > 40 ? (lang === 'hi' ? 'ठीक' : 'Fair') : (lang === 'hi' ? 'खराब' : 'Needs Care');

    // Group by Category
    const categoryMap: Record<string, number> = {};
    let totalForPie = 0;
    transactions
      .filter(t => t.type === TransactionType.EXPENSE)
      .forEach(t => {
        categoryMap[t.category] = (categoryMap[t.category] || 0) + t.amount;
        totalForPie += t.amount;
      });
    
    const pieData = Object.keys(categoryMap).map(key => ({
      name: key,
      value: categoryMap[key],
      percentage: totalForPie > 0 ? (categoryMap[key] / totalForPie) * 100 : 0
    })).sort((a, b) => b.value - a.value);

    return { totalSpent, suspiciousCount, pieData, totalForPie, score, healthColor, healthLabel };
  }, [transactions, user, lang]);

  useEffect(() => {
      const fetchTip = async () => {
          if (transactions.length === 0) return;
          setLoadingTip(true);
          const tip = await getBudgetInsight(transactions, user.budgetLimit);
          setAiTip(tip);
          setLoadingTip(false);
      };
      fetchTip();
  }, [transactions, user.budgetLimit]);

  const handleQuickAction = (action: string) => {
      setActiveModal(action);
      setAmount('');
      setIdentifier('');
      setDescription('');
      setBeneficiaryName('');
      setNewBankName('');
      setNewBankAcc('');
      setNewBankIfsc('');
      setScanStep('SCAN');
      setIsProcessing(false);
  };

  const closeModal = () => {
      setActiveModal(null);
      setModalData(null);
  }

  // --- HANDLERS ---
  const handleAddMoneySubmit = () => {
      if (!amount) return;
      // Note: Add Money adds to balance, so no insufficient check needed.
      // But we still require PIN for security.
      onTransactionRequest({
          amount: parseFloat(amount),
          category: Category.OTHER,
          description: "Wallet Top-up",
          type: TransactionType.INCOME
      }, () => {
          closeModal(); // Only close on success PIN
      });
  };

  const handleQrPayment = () => {
      const payAmount = parseFloat(amount);
      if (!payAmount) return;

      if (payAmount > user.balance) {
          alert(`❌ Transaction Failed\n\nInsufficient balance! Your available balance is ₹${user.balance}.`);
          return;
      }

      onTransactionRequest({
          amount: payAmount,
          category: Category.OTHER,
          description: `QR Payment: ${description || 'Merchant'}`,
          type: TransactionType.EXPENSE,
          location: 'Delhi' // Simulated Geo-location
      }, () => {
          closeModal();
      });
  };

  const handleMobileTransfer = () => {
      if (!amount || !identifier) return;
      const transferAmount = parseFloat(amount);
      
      if (transferAmount > user.balance) {
          alert(`❌ Transaction Failed\n\nInsufficient balance! Your available balance is ₹${user.balance}.`);
          return;
      }

      onTransactionRequest({
          amount: transferAmount,
          category: Category.OTHER,
          description: `Transfer to ${identifier}`,
          type: TransactionType.TRANSFER
      }, () => {
          closeModal();
      });
  };

  const handleBankTransfer = () => {
       if (!amount || !newBankAcc || !newBankIfsc) return;
       const transferAmount = parseFloat(amount);
       
       if (transferAmount > user.balance) {
           alert(`❌ Transaction Failed\n\nInsufficient balance! Your available balance is ₹${user.balance}.`);
           return;
       }

       onTransactionRequest({
           amount: transferAmount,
           category: Category.OTHER,
           description: `Transfer to ${beneficiaryName || 'Bank A/c'} (${newBankAcc})`,
           type: TransactionType.TRANSFER
       }, () => {
           closeModal();
       });
  };

  const handleSelfTransfer = () => {
      if (!amount || !selectedBankId) return;
      const transferAmount = parseFloat(amount);
      
      if (transferAmount > user.balance) {
          alert(`❌ Transaction Failed\n\nInsufficient balance! Your available balance is ₹${user.balance}.`);
          return;
      }

      const bank = user.linkedBanks.find(b => b.id === selectedBankId);
      onTransactionRequest({
          amount: transferAmount,
          category: Category.OTHER,
          description: `Withdraw to ${bank?.bankName} (...${bank?.accountNumber.slice(-4)})`,
          type: TransactionType.TRANSFER
      }, () => {
          closeModal();
      });
  };

  const handleAddBankSubmit = () => {
      if (!newBankName || !newBankAcc || !newBankIfsc) return;
      // Adding a bank isn't a financial transaction on ledger, just profile update
      onAddBank({
          id: Date.now().toString(),
          bankName: newBankName,
          accountNumber: newBankAcc,
          ifsc: newBankIfsc,
          isPrimary: false
      });
      setNewBankName('');
      setNewBankAcc('');
      setNewBankIfsc('');
      setActiveModal('PAY_SELF'); 
  };

  const handleBillPay = (category: string) => {
      if (!amount) return;
      const billAmount = parseFloat(amount);
      
      if (billAmount > user.balance) {
          alert(`❌ Transaction Failed\n\nInsufficient balance for ${category} recharge. Available: ₹${user.balance}.`);
          return;
      }

      onTransactionRequest({
          amount: billAmount,
          category: Category.BILLS,
          description: `${modalData || category} Payment`,
          type: TransactionType.EXPENSE
      }, () => {
          closeModal();
      });
  }

  const renderModal = () => {
      if (!activeModal) return null;

      switch (activeModal) {
          case 'ADD_MONEY':
              return (
                  <ModalContainer title="Add Money to Wallet" onClose={closeModal}>
                      <div className="space-y-4">
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount</label>
                              <div className="relative">
                                  <span className="absolute left-3 top-3 text-slate-400 font-bold">₹</span>
                                  <input type="number" value={amount} onChange={e => setAmount(e.target.value)} autoFocus className="w-full pl-8 p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white font-bold text-lg" />
                              </div>
                          </div>
                          <button onClick={handleAddMoneySubmit} disabled={!amount} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium flex justify-center">
                              Secure Add (PIN Required)
                          </button>
                      </div>
                  </ModalContainer>
              );
          // ... Other modals remain similar but call new handlers above ...
          case 'SCAN_QR':
             return (
                 <ModalContainer title="Scan & Pay" onClose={closeModal}>
                      {scanStep === 'SCAN' ? (
                          <div className="flex flex-col items-center space-y-4">
                              <div className="w-64 h-64 bg-black rounded-2xl relative overflow-hidden flex items-center justify-center group cursor-pointer" onClick={() => setScanStep('PAY')}>
                                  <div className="absolute inset-0 opacity-50 bg-[url('https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=Demo')] bg-cover bg-center"></div>
                                  <div className="absolute inset-0 border-2 border-indigo-500/50 m-8 rounded-lg animate-pulse"></div>
                                  <div className="w-full h-1 bg-red-500 absolute top-0 animate-[scan_2s_ease-in-out_infinite] shadow-[0_0_10px_#ef4444]"></div>
                                  <p className="relative z-10 text-white font-bold bg-black/50 px-3 py-1 rounded-full text-xs">Tap to Simulate Scan</p>
                              </div>
                              <p className="text-xs text-slate-500 text-center">Point camera at any UPI QR Code</p>
                          </div>
                      ) : (
                          <div className="space-y-4">
                              <div className="flex items-center space-x-3 p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl mb-2">
                                  <div className="bg-indigo-100 dark:bg-indigo-800 p-2 rounded-full">
                                      <Building size={20} className="text-indigo-600 dark:text-indigo-400"/>
                                  </div>
                                  <div>
                                      <p className="font-bold text-sm text-slate-800 dark:text-white">Paying Merchant</p>
                                      <p className="text-xs text-slate-500 dark:text-slate-400">credify@upi</p>
                                  </div>
                              </div>
                              <div>
                                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount</label>
                                  <input type="number" value={amount} onChange={e => setAmount(e.target.value)} autoFocus className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white font-bold text-lg" placeholder="0.00" />
                              </div>
                              <div>
                                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Note (Optional)</label>
                                  <input type="text" value={description} onChange={e => setDescription(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none dark:text-white" placeholder="Payment for..." />
                              </div>
                              <button onClick={handleQrPayment} disabled={!amount} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium flex justify-center">
                                  Verify & Pay
                              </button>
                          </div>
                      )}
                 </ModalContainer>
             );
          case 'PAY_MOBILE':
              return (
                  <ModalContainer title="Pay to Mobile" onClose={closeModal}>
                       <div className="space-y-4">
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Mobile Number</label>
                              <input type="text" value={identifier} onChange={e => setIdentifier(e.target.value)} autoFocus className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="98765xxxxx" />
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount</label>
                              <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white font-bold text-lg" placeholder="0.00" />
                          </div>
                          <button onClick={handleMobileTransfer} disabled={!amount || !identifier} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium flex justify-center">
                              Verify & Pay
                          </button>
                       </div>
                  </ModalContainer>
              );
          case 'PAY_BANK':
              return (
                  <ModalContainer title="Bank Transfer" onClose={closeModal}>
                      <div className="space-y-4">
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Account Number</label>
                              <input type="text" value={newBankAcc} onChange={e => setNewBankAcc(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="Account No." />
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">IFSC Code</label>
                              <input type="text" value={newBankIfsc} onChange={e => setNewBankIfsc(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="IFSC Code" />
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount</label>
                              <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white font-bold text-lg" placeholder="0.00" />
                          </div>
                          <button onClick={handleBankTransfer} disabled={!amount || !newBankAcc || !newBankIfsc} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium flex justify-center">
                              Verify & Pay
                          </button>
                      </div>
                  </ModalContainer>
              );
          case 'ADD_BANK':
              return (
                   <ModalContainer title="Link Bank Account" onClose={closeModal}>
                       <div className="space-y-4">
                           <div className="p-3 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 text-xs rounded-xl flex items-start">
                               <Landmark size={16} className="mr-2 flex-shrink-0 mt-0.5" />
                               This account will be linked to your profile for self-transfers.
                           </div>
                           <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Bank Name</label>
                              <input type="text" value={newBankName} onChange={e => setNewBankName(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="e.g. HDFC Bank" />
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Account Number</label>
                              <input type="text" value={newBankAcc} onChange={e => setNewBankAcc(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="Account No." />
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">IFSC Code</label>
                              <input type="text" value={newBankIfsc} onChange={e => setNewBankIfsc(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" placeholder="IFSC" />
                          </div>
                          <button onClick={handleAddBankSubmit} disabled={!newBankName || !newBankAcc || !newBankIfsc} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium">
                              Link Account
                          </button>
                       </div>
                   </ModalContainer>
              );
          case 'PAY_SELF':
              return (
                   <ModalContainer title="Self Transfer" onClose={closeModal}>
                       <div className="space-y-4">
                           {user.linkedBanks.length === 0 ? (
                               <div className="text-center py-6">
                                   <div className="bg-slate-100 dark:bg-slate-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                                       <Landmark size={24} className="text-slate-400" />
                                   </div>
                                   <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">No bank accounts linked.</p>
                                   <button onClick={() => setActiveModal('ADD_BANK')} className="text-indigo-600 font-bold hover:underline">
                                       Link Bank Account
                                   </button>
                               </div>
                           ) : (
                               <>
                                   <div>
                                       <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Transfer To</label>
                                       <div className="space-y-2">
                                           {user.linkedBanks.map(bank => (
                                               <div 
                                                    key={bank.id} 
                                                    onClick={() => setSelectedBankId(bank.id)}
                                                    className={`p-3 rounded-xl border flex items-center cursor-pointer transition-all ${selectedBankId === bank.id ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300'}`}
                                               >
                                                   <div className="bg-indigo-100 dark:bg-indigo-800 p-2 rounded-lg mr-3">
                                                       <Landmark size={20} className="text-indigo-600 dark:text-indigo-400" />
                                                   </div>
                                                   <div>
                                                       <p className="font-bold text-sm text-slate-800 dark:text-white">{bank.bankName}</p>
                                                       <p className="text-xs text-slate-500 dark:text-slate-400">XXXX{bank.accountNumber.slice(-4)}</p>
                                                   </div>
                                                   {selectedBankId === bank.id && <CheckCircle size={18} className="ml-auto text-indigo-600 dark:text-indigo-400" />}
                                               </div>
                                           ))}
                                       </div>
                                   </div>
                                   <div>
                                      <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount</label>
                                      <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white font-bold text-lg" placeholder="0.00" />
                                   </div>
                                   <button onClick={handleSelfTransfer} disabled={!amount || !selectedBankId} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium flex justify-center">
                                       Verify & Transfer
                                   </button>
                               </>
                           )}
                       </div>
                   </ModalContainer>
              );
          case 'BILL_PAY':
              return (
                  <ModalContainer title={`${modalData || 'Bill'} Payment`} onClose={closeModal}>
                      <div className="space-y-4">
                          <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl flex flex-col items-center">
                              <p className="text-sm font-medium text-slate-500 uppercase tracking-wide">Paying For</p>
                              <p className="text-lg font-bold text-slate-800 dark:text-white mt-1">{modalData || 'Utility'}</p>
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount</label>
                              <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white font-bold text-lg" placeholder="0.00" />
                          </div>
                          <button onClick={() => handleBillPay(modalData)} disabled={!amount} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-medium flex justify-center">
                              Verify & Pay
                          </button>
                      </div>
                  </ModalContainer>
              );
          default:
              return null;
      }
  };

  const quickActions = [
    { id: 'SCAN_QR', icon: ScanLine, label: 'Scan any QR', color: 'bg-indigo-600' },
    { id: 'PAY_MOBILE', icon: Smartphone, label: 'To Mobile', color: 'bg-blue-500' },
    { id: 'PAY_SELF', icon: User, label: 'To Self', color: 'bg-emerald-500' },
    { id: 'PAY_BANK', icon: Building, label: 'To Bank', color: 'bg-purple-500' },
  ];

  const billActions = [
      { id: 'Mobile Recharge', icon: SmartphoneCharging, color: 'text-blue-500 bg-blue-50 dark:bg-blue-900/20' },
      { id: 'DTH', icon: Tv, color: 'text-orange-500 bg-orange-50 dark:bg-orange-900/20' },
      { id: 'Electricity', icon: Zap, color: 'text-yellow-500 bg-yellow-50 dark:bg-yellow-900/20' },
      { id: 'Credit Card', icon: CreditCard, color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' },
      { id: 'Broadband', icon: Wifi, color: 'text-pink-500 bg-pink-50 dark:bg-pink-900/20' },
      { id: 'Fastag', icon: Car, color: 'text-slate-500 bg-slate-50 dark:bg-slate-900/20' },
  ];

  return (
    <div className="space-y-6 animate-fade-in pb-20">
      
      {renderModal()}

      {/* UPI Header Card */}
      <div className="relative overflow-hidden bg-slate-900 text-white rounded-3xl p-6 shadow-2xl">
           <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
           
           <div className="relative z-10">
               <div className="flex justify-between items-start mb-6">
                   <div>
                       <h2 className="text-slate-400 text-sm font-medium uppercase tracking-wider">{t(lang, 'totalBalance')}</h2>
                       <div className="flex items-center space-x-2 mt-1">
                           <span className="text-3xl font-bold">₹{user.balance.toLocaleString()}</span>
                           <button className="bg-slate-800 p-1.5 rounded-full hover:bg-slate-700 transition-colors">
                               <ArrowRightLeft size={14} className="text-slate-300"/>
                           </button>
                       </div>
                       <p className="text-xs text-slate-400 mt-2 font-mono flex items-center">
                           UPI ID: credify@{user.linkedBanks[0]?.bankName.split(' ')[0].toLowerCase() || 'upi'} 
                           <span className="ml-2 bg-slate-800 px-1.5 py-0.5 rounded text-[10px] cursor-pointer hover:bg-slate-700">Copy</span>
                       </p>
                   </div>
                   <div className="bg-white p-2 rounded-xl">
                       <QrCode className="text-slate-900" size={40} />
                   </div>
               </div>

               {/* Quick Add Money Row */}
               <div className="flex space-x-3">
                   <button onClick={() => handleQuickAction('ADD_MONEY')} className="flex-1 bg-indigo-600 hover:bg-indigo-700 py-2.5 rounded-xl font-medium text-sm transition-colors flex items-center justify-center">
                       <PlusCircle size={16} className="mr-2" /> Add Money
                   </button>
                   <button onClick={() => handleQuickAction('PAY_SELF')} className="flex-1 bg-slate-800 hover:bg-slate-700 py-2.5 rounded-xl font-medium text-sm transition-colors border border-slate-700">
                       Check Balance
                   </button>
               </div>
           </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-4 gap-4">
          {quickActions.map(action => (
              <button 
                key={action.id} 
                onClick={() => handleQuickAction(action.id)}
                className="flex flex-col items-center space-y-2 group"
              >
                  <div className={`${action.color} p-4 rounded-2xl shadow-lg text-white group-hover:scale-105 transition-transform duration-200`}>
                      <action.icon size={24} />
                  </div>
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-300">{action.label}</span>
              </button>
          ))}
      </div>

      {/* Bill Payments */}
      <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700">
          <h3 className="font-bold text-slate-800 dark:text-white mb-4">Recharge & Pay Bills</h3>
          <div className="grid grid-cols-4 md:grid-cols-6 gap-4">
              {billActions.map(bill => (
                  <button 
                    key={bill.id} 
                    onClick={() => {
                        setModalData(bill.id);
                        handleQuickAction('BILL_PAY');
                    }}
                    className="flex flex-col items-center space-y-2"
                  >
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${bill.color} transition-transform active:scale-95`}>
                          <bill.icon size={20} />
                      </div>
                      <span className="text-[10px] text-center font-medium text-slate-600 dark:text-slate-400 leading-tight">{bill.id}</span>
                  </button>
              ))}
          </div>
      </div>
      
      {/* Alert Banner */}
      {stats.suspiciousCount > 0 && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4 flex items-start space-x-3 animate-pulse">
              <AlertTriangle className="text-red-500 shrink-0 mt-0.5" />
              <div>
                  <h3 className="font-bold text-red-700 dark:text-red-400 text-sm">{t(lang, 'riskAlerts')}</h3>
                  <p className="text-xs text-red-600 dark:text-red-300 mt-1">
                      {stats.suspiciousCount} suspicious transactions detected. Please review your ledger immediately.
                  </p>
              </div>
          </div>
      )}

      {/* AI Insight */}
      {aiTip && (
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-5 rounded-xl shadow-lg flex items-start space-x-3">
            <Sparkles className="shrink-0 mt-1 text-yellow-300" />
            <div>
                <h3 className="font-bold text-sm mb-1">Smart Budget Insight</h3>
                <p className="text-xs opacity-90 leading-relaxed">
                   {loadingTip ? "Analyzing financial patterns..." : aiTip}
                </p>
            </div>
        </div>
      )}

      {/* Charts & Stats (Same as before) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center text-center relative overflow-hidden">
              <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-4">{t(lang, 'financialHealth')}</h3>
              
              <div className="relative w-40 h-40 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90">
                      <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="10" fill="transparent" className="text-slate-100 dark:text-slate-700" />
                      <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="10" fill="transparent" strokeDasharray={440} strokeDashoffset={440 - (440 * stats.score) / 100} className={`${stats.healthColor} transition-all duration-1000 ease-out`} />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className={`text-4xl font-extrabold ${stats.healthColor}`}>{stats.score}</span>
                      <span className="text-xs font-bold text-slate-400 mt-1">/ 100</span>
                  </div>
              </div>
              <p className={`mt-2 font-bold ${stats.healthColor}`}>{stats.healthLabel}</p>
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col">
              <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-4">{t(lang, 'expenseCat')}</h3>
              
              <div className="flex-1 flex items-center space-x-6">
                  <div className="w-32 h-32 rounded-full relative shrink-0" style={{ background: stats.pieData.length ? `conic-gradient(${stats.pieData.map((d, i, arr) => {
                      const prevSum = arr.slice(0, i).reduce((sum, item) => sum + item.percentage, 0);
                      return `${COLORS[i % COLORS.length]} ${prevSum}% ${prevSum + d.percentage}%`;
                  }).join(', ')})` : '#e2e8f0' }}>
                      <div className="absolute inset-0 m-6 bg-white dark:bg-slate-800 rounded-full"></div>
                  </div>

                  <div className="flex-1 space-y-2 overflow-y-auto max-h-40 no-scrollbar">
                      {stats.pieData.map((entry, index) => (
                          <div key={index} className="flex items-center justify-between text-xs">
                              <div className="flex items-center">
                                  <div className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                                  <span className="text-slate-600 dark:text-slate-300 truncate max-w-[80px]">{entry.name}</span>
                              </div>
                              <span className="font-bold text-slate-800 dark:text-white">₹{entry.value.toLocaleString()}</span>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      </div>
      
      {/* Recent Transactions */}
      <div>
          <h3 className="font-bold text-slate-800 dark:text-white mb-4 flex items-center">
              <History className="mr-2 text-slate-400" size={18} />
              Recent Activity
          </h3>
          <div className="space-y-3">
              {transactions.slice(0, 4).map(t => (
                  <div key={t.id} className={`bg-white dark:bg-slate-800 p-4 rounded-xl border ${t.isSuspicious ? 'border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-900/10' : 'border-slate-100 dark:border-slate-700'} flex justify-between items-center`}>
                      <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              t.type === 'INCOME' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' : 'bg-slate-100 text-slate-600 dark:bg-slate-900/50 dark:text-slate-400'
                          }`}>
                              {t.type === 'INCOME' ? <ArrowRightLeft size={16} /> : <CreditCard size={16} />}
                          </div>
                          <div>
                              <p className="font-bold text-sm text-slate-800 dark:text-white">{t.description}</p>
                              <p className="text-xs text-slate-500">{new Date(t.date).toLocaleDateString()}</p>
                          </div>
                      </div>
                      <div className="text-right">
                          <span className={`font-bold text-sm ${t.type === 'INCOME' ? 'text-green-600' : 'text-slate-800 dark:text-white'}`}>
                              {t.type === 'INCOME' ? '+' : '-'}₹{t.amount}
                          </span>
                          {t.isSuspicious && (
                              <p className="text-[10px] text-red-500 font-bold mt-1">⚠️ Suspicious</p>
                          )}
                      </div>
                  </div>
              ))}
          </div>
      </div>

    </div>
  );
};

export default Dashboard;
