
import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Lock, User, Mail, CheckCircle, Shield, AlertCircle, KeyRound } from 'lucide-react';
import { api } from '../services/api';

interface LoginProps {
  onLogin: (user: any) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [step, setStep] = useState<'credentials' | 'otp'>('credentials');
  
  const [name, setName] = useState('');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [newPin, setNewPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!identifier || !password) {
        setError("Please fill in all fields.");
        return;
    }
    
    // Strict email/mobile validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobileRegex = /^[0-9]{10}$/;
    
    if (!emailRegex.test(identifier) && !mobileRegex.test(identifier)) {
        setError("Please enter a valid Email or 10-digit Mobile Number");
        return;
    }

    if (isSignUp && (!name || !newPin || newPin.length !== 4)) {
        setError("Please enter name and a 4-digit PIN.");
        return;
    }

    setLoading(true);

    try {
        if (isSignUp) {
            const res = await api.register(name, identifier, password, newPin);
            if (res.token) {
                localStorage.setItem('credify_token', res.token);
                onLogin(res.user);
            } else {
                setError(res.msg || "Registration failed");
            }
        } else {
            const res = await api.login(identifier, password);
            if (res.token) {
                localStorage.setItem('credify_token', res.token);
                // For demo simplicity, we skip OTP if backend login is successful
                // In a real flow, you'd trigger OTP here
                onLogin(res.user);
            } else {
                setError(res.msg || "Invalid credentials");
            }
        }
    } catch (err) {
        setError("Server connection failed. Is the backend running?");
    } finally {
        setLoading(false);
    }
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      // Only used if we want to enforce OTP on frontend *after* password check
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4 transition-colors duration-200">
      <div className="max-w-4xl w-full bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row border border-slate-100 dark:border-slate-800">
        
        {/* Left Side - Brand & Info */}
        <div className="md:w-1/2 bg-gradient-to-br from-indigo-600 to-purple-700 p-8 md:p-12 text-white flex flex-col justify-between relative overflow-hidden">
            <div className="relative z-10">
                <div className="flex items-center space-x-2 mb-8">
                    <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
                        <ShieldCheck className="text-white w-8 h-8" />
                    </div>
                    <span className="font-bold text-2xl tracking-tight">Credify</span>
                </div>
                
                <h2 className="text-3xl font-bold mb-4 leading-tight">
                    {isSignUp ? "Start Your Financial Journey Today." : "Welcome Back!"}
                </h2>
                <p className="text-indigo-100 opacity-90 leading-relaxed">
                    {isSignUp 
                        ? "Join thousands of students and families securing their future with blockchain-powered finance."
                        : "Track expenses, manage budgets, and learn financial literacy with complete transparency."
                    }
                </p>
            </div>

            <div className="relative z-10 mt-12 space-y-4">
                <div className="flex items-center space-x-3 text-sm opacity-90">
                    <CheckCircle size={18} className="text-emerald-300" />
                    <span>Blockchain Secured Ledger</span>
                </div>
                <div className="flex items-center space-x-3 text-sm opacity-90">
                    <Shield size={18} className="text-emerald-300" />
                    <span>Bank-Grade Encryption</span>
                </div>
                <div className="flex items-center space-x-3 text-sm opacity-90">
                    <KeyRound size={18} className="text-emerald-300" />
                    <span>Mandatory PIN Security</span>
                </div>
            </div>

            <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 rounded-full bg-white/10 blur-3xl"></div>
            <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-purple-500/30 blur-3xl"></div>
        </div>

        {/* Right Side - Form */}
        <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
            <div className="mb-6 text-center md:text-left">
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">
                    {isSignUp ? "Create Account" : "Login to Account"}
                </h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">
                    {isSignUp ? "Enter your details below" : "Enter your email address"}
                </p>
                {!isSignUp && (
                    <div className="mt-2 text-xs text-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 p-2 rounded-lg inline-block">
                        Admin Demo: <b>admin@credify.com</b> / <b>admin123</b>
                    </div>
                )}
            </div>

            {error && (
                <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-xl flex items-start space-x-2 animate-fade-in">
                    <AlertCircle className="text-red-500 mt-0.5 flex-shrink-0" size={16} />
                    <p className="text-xs text-red-600 dark:text-red-300 font-medium">{error}</p>
                </div>
            )}

            <form onSubmit={handleCredentialsSubmit} className="space-y-4">
                {isSignUp && (
                    <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Full Name</label>
                        <div className="relative">
                            <User className="absolute left-3 top-3.5 text-slate-400" size={18} />
                            <input 
                                type="text" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white transition-all placeholder:text-slate-400"
                                placeholder="John Doe"
                            />
                        </div>
                    </div>
                )}

                <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Email Address</label>
                    <div className="relative">
                        <Mail className="absolute left-3 top-3.5 text-slate-400" size={18} />
                        <input 
                            type="text" 
                            value={identifier}
                            onChange={(e) => {
                                setIdentifier(e.target.value);
                                setError('');
                            }}
                            className={`w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border ${identifier && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier) && !/^[0-9]{10}$/.test(identifier) ? 'border-red-400 focus:ring-red-400' : 'border-slate-200 dark:border-slate-700 focus:ring-indigo-500'} rounded-xl focus:outline-none focus:ring-2 text-slate-900 dark:text-slate-900 transition-all placeholder:text-slate-400`}
                            placeholder="user@example.com"
                        />
                    </div>
                </div>

                {isSignUp && (
                        <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Create Security PIN (4-Digits)</label>
                        <div className="relative">
                            <KeyRound className="absolute left-3 top-3.5 text-slate-400" size={18} />
                            <input 
                                type="password" 
                                value={newPin}
                                maxLength={4}
                                onChange={(e) => setNewPin(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-slate-900 transition-all placeholder:text-slate-400 tracking-widest"
                                placeholder="••••"
                            />
                        </div>
                    </div>
                )}

                <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Password</label>
                    <div className="relative">
                        <Lock className="absolute left-3 top-3.5 text-slate-400" size={18} />
                        <input 
                            type="password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-slate-900 transition-all placeholder:text-slate-400"
                            placeholder="••••••••"
                        />
                    </div>
                </div>

                <button 
                    type="submit" 
                    disabled={loading || !identifier || !password}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-indigo-200 dark:shadow-none hover:shadow-xl transition-all active:scale-95 flex items-center justify-center disabled:opacity-70 disabled:cursor-not-allowed mt-4"
                >
                    {loading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                        <>
                            {isSignUp ? "Set PIN & Sign Up" : "Proceed Securely"}
                            <ArrowRight size={18} className="ml-2" />
                        </>
                    )}
                </button>
            </form>

            <div className="mt-8 text-center">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                    {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                    <button 
                        onClick={() => {
                            setIsSignUp(!isSignUp);
                            setError('');
                        }}
                        className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                    >
                        {isSignUp ? "Login" : "Sign Up"}
                    </button>
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
