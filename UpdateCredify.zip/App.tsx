
import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Wallet as WalletIcon, ListPlus, GraduationCap, Menu, LogOut, Moon, Sun, Target, FileCode, Fingerprint, TrendingUp, Languages, Lock, KeyRound, ArrowRight } from 'lucide-react';
import Dashboard from './components/Dashboard';
import Wallet from './components/Wallet';
import Expenses from './components/Expenses';
import Education from './components/Education';
import Goals from './components/Goals';
import Login from './components/Login';
import SmartContracts from './components/SmartContracts';
import Identity from './components/Identity';
import Investments from './components/Investments';
import AdminDashboard from './components/AdminDashboard'; // New Import
import PinModal from './components/PinModal'; 
import { Transaction, Block, UserProfile, Category, TransactionType, SavingsGoal, Bill, SmartContract, Stock, Language, BankAccount, TransactionRequest, PinState, FraudAnalysis } from './types';
import { api } from './services/api'; // Real API
import { t } from './services/translations';

// Navigation Items
const NAV_KEYS = [
  { id: 'dashboard', icon: LayoutDashboard },
  { id: 'expenses', icon: ListPlus },
  { id: 'wallet', icon: WalletIcon },
  { id: 'investments', icon: TrendingUp },
  { id: 'contracts', icon: FileCode },
  { id: 'goals', icon: Target },
  { id: 'education', icon: GraduationCap },
  { id: 'identity', icon: Fingerprint },
];

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [lang, setLang] = useState<Language>('en'); 
  
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('credify_theme') === 'dark';
    }
    return false;
  });

  const [isAuthenticated, setIsAuthenticated] = useState(() => {
      return !!localStorage.getItem('credify_token');
  });

  const [isAdmin, setIsAdmin] = useState(false); // Admin State

  // Recovery State
  const [isRecovering, setIsRecovering] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryOtp, setRecoveryOtp] = useState('');

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('credify_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('credify_theme', 'light');
    }
  }, [darkMode]);
  
  // -- STATE --
  // Initial state is partial/empty until fetched from API
  const [user, setUser] = useState<UserProfile>({
      name: "User",
      did: "did:loading...",
      balance: 0,
      lockedBalance: 0,
      tokenBalance: 0, 
      currency: "INR",
      language: 'en',
      budgetLimit: 8000,
      trustScore: 85,
      portfolio: [],
      linkedBanks: [
          { id: '1', bankName: 'State Bank of India', accountNumber: 'XXXX8921', ifsc: 'SBIN0001234', isPrimary: true }
      ],
      isWalletLocked: false
  });

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [chain, setChain] = useState<Block[]>([]);
  const [goals, setGoals] = useState<SavingsGoal[]>([]); // mock for now
  const [contracts, setContracts] = useState<SmartContract[]>([]); // mock for now
  const [bills, setBills] = useState<Bill[]>([
      { id: '1', name: 'Electricity Bill', amount: 850, dueDate: new Date(Date.now() + 259200000).toISOString(), isPaid: false },
      { id: '2', name: 'Mobile Recharge', amount: 299, dueDate: new Date(Date.now() - 86400000).toISOString(), isPaid: false }
  ]);

  // -- SECURITY STATE --
  const [pinState, setPinState] = useState<PinState>({
      isOpen: false,
      attempts: 0,
      isLocked: false,
      lockUntil: null
  });
  
  const [pendingTx, setPendingTx] = useState<{
      req: TransactionRequest; 
      onSuccess?: () => void;
  } | null>(null);

  // -- FETCH DATA ON MOUNT --
  useEffect(() => {
      if (isAuthenticated && !isAdmin) {
          fetchUserData();
      }
  }, [isAuthenticated, isAdmin]);

  const fetchUserData = async () => {
      try {
          const balanceData = await api.getBalance();
          const ledgerData = await api.getHistory(); // blocks/transactions
          
          setUser(prev => ({ 
              ...prev, 
              balance: balanceData.balance,
              isWalletLocked: balanceData.isLocked 
          }));

          // Transform Blocks to Transactions for UI
          const txHistory = ledgerData.map((block: any) => ({
              ...block.data,
              hash: block.hash,
              id: block._id || block.hash
          }));
          
          setTransactions(txHistory);
          setChain(ledgerData);

      } catch (err) {
          console.error("Failed to fetch user data", err);
          if (isAuthenticated) alert("Could not connect to server.");
      }
  };

  const handleLogin = (userData: any) => {
      setIsAuthenticated(true);
      if (userData.isAdmin) {
          setIsAdmin(true);
      } else {
          setUser(prev => ({ ...prev, name: userData.name, email: userData.email }));
          fetchUserData();
      }
  };

  const handleLogout = () => {
      setIsAuthenticated(false);
      setIsAdmin(false);
      localStorage.removeItem('credify_token');
      setActiveTab('dashboard');
  };

  const handleRecoverySubmit = async () => {
      if (!recoveryEmail || !recoveryOtp) return;
      
      const res = await api.recoverWallet(recoveryEmail, recoveryOtp);
      if (res.success) {
          alert("✅ Identity Verified! Wallet Unlocked.");
          setIsRecovering(false);
          setRecoveryOtp('');
          setRecoveryEmail('');
          fetchUserData(); // Refresh lock status
      } else {
          alert(`❌ Recovery Failed: ${res.message}`);
      }
  };

  // 1. Intercept Transaction Request
  const handleTransactionRequest = (request: TransactionRequest, onSuccess?: () => void) => {
      if (user.isWalletLocked) {
          alert("⛔ WALLET LOCKED: Please wait or contact support.");
          return;
      }

      // Pre-flight balance check
      const debitTypes = [
          TransactionType.EXPENSE, 
          TransactionType.TRANSFER, 
          TransactionType.CONTRACT_LOCK, 
          TransactionType.INVESTMENT,
          TransactionType.SAVINGS
      ];

      if (debitTypes.includes(request.type)) {
          if (request.amount > user.balance) {
              alert(`❌ Transaction Failed\n\nInsufficient balance in your account! Your available balance is ₹${user.balance.toLocaleString()}.`);
              return;
          }
      }

      setPendingTx({ req: request, onSuccess });
      setPinState(prev => ({ ...prev, isOpen: true, attempts: 0 }));
  };

  // 2. Verify PIN & Process via Backend
  const handlePinSubmit = async (inputPin: string) => {
      if (!pendingTx) return;

      try {
          // Send to backend
          const res = await api.sendTransaction(pendingTx.req, inputPin);

          if (res.success) {
              // Success
              setPinState({ isOpen: false, attempts: 0, isLocked: false, lockUntil: null });
              
              if (res.fraudAlert) {
                   alert(`⚠️ SUSPICIOUS ACTIVITY DETECTED\n\nReason: ${res.message}\nTransaction flagged.`);
              } else {
                   // alert("Transaction Successful");
              }

              // Refresh Data
              fetchUserData();

              if (pendingTx.onSuccess) pendingTx.onSuccess();
              setPendingTx(null);

          } else {
              // Failed (PIN or Error)
              if (res.message.includes('PIN')) {
                  const newAttempts = pinState.attempts + 1;
                  if (newAttempts >= 3) {
                      setPinState(prev => ({ ...prev, attempts: newAttempts, isOpen: false, isLocked: true }));
                      setUser(prev => ({ ...prev, isWalletLocked: true }));
                      alert("⛔ WALLET LOCKED: Too many incorrect PIN attempts.");
                  } else {
                      setPinState(prev => ({ ...prev, attempts: newAttempts }));
                      alert(`Incorrect PIN. ${3 - newAttempts} attempts left.`);
                  }
              } else {
                  alert(`Error: ${res.message}`);
              }
          }
      } catch (err) {
          console.error(err);
          alert("Transaction Error: Server unreachable");
      }
  };

  // -- COMPONENT HANDLERS --

  const handleAddBank = (bank: BankAccount) => {
      setUser(prev => ({ ...prev, linkedBanks: [...prev.linkedBanks, bank] }));
  };

  const handleCreateContract = (contract: SmartContract) => {
      handleTransactionRequest({
          amount: contract.amount,
          category: Category.CONTRACT,
          description: `Smart Contract Lock: ${contract.name}`,
          type: TransactionType.CONTRACT_LOCK
      }, () => {
          setContracts(prev => [...prev, contract]);
      });
  };

  const handleWithdrawContract = (id: string) => {
      const contract = contracts.find(c => c.id === id);
      if (!contract) return;
      
      handleTransactionRequest({
          amount: contract.amount,
          category: Category.CONTRACT,
          description: `Contract Executed: ${contract.name}`,
          type: TransactionType.CONTRACT_UNLOCK
      }, () => {
          const updatedContracts = contracts.map(c => c.id === id ? { ...c, status: 'EXECUTED' as const } : c);
          setContracts(updatedContracts);
      });
  };

  const handleBuyStock = (stock: Stock, quantity: number) => {
    const totalCost = stock.price * quantity;
    handleTransactionRequest({
        amount: totalCost,
        category: Category.INVESTMENT,
        description: `Bought ${quantity} ${stock.symbol}`,
        type: TransactionType.INVESTMENT
    }, () => {
        const updatedPortfolio = [...user.portfolio];
        const existingIndex = updatedPortfolio.findIndex(p => p.symbol === stock.symbol);
        if (existingIndex >= 0) {
          const existing = updatedPortfolio[existingIndex];
          const newQty = existing.quantity + quantity;
          updatedPortfolio[existingIndex] = { ...existing, quantity: newQty };
        } else {
          updatedPortfolio.push({ symbol: stock.symbol, name: stock.name, quantity, avgPrice: stock.price });
        }
        setUser(prev => ({ ...prev, portfolio: updatedPortfolio }));
    });
  };

  const handleAddGoal = (goal: SavingsGoal) => setGoals([...goals, goal]);

  const handleContributeToGoal = (goalId: string, amount: number) => {
    handleTransactionRequest({
        amount,
        category: Category.SAVINGS,
        description: "Goal Contribution",
        type: TransactionType.EXPENSE
    }, () => {
        const updatedGoals = goals.map(g => g.id === goalId ? { ...g, currentAmount: g.currentAmount + amount } : g);
        setGoals(updatedGoals);
    });
  };

  const handlePayBill = (id: string) => {
    const bill = bills.find(b => b.id === id);
    if (!bill || bill.isPaid) return;
    
    handleTransactionRequest({
        amount: bill.amount,
        category: Category.BILLS,
        description: `Bill: ${bill.name}`,
        type: TransactionType.EXPENSE
    }, () => {
        setBills(prev => prev.map(b => b.id === id ? { ...b, isPaid: true } : b));
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard transactions={transactions} user={user} bills={bills} onPayBill={handlePayBill} lang={lang} onTransactionRequest={handleTransactionRequest} onAddBank={handleAddBank} />;
      case 'expenses': return <Expenses transactions={transactions} onTransactionRequest={handleTransactionRequest} lang={lang} />;
      case 'wallet': return <Wallet chain={chain} onTransactionRequest={handleTransactionRequest} user={user} lang={lang} />;
      case 'investments': return <Investments user={user} onBuyStock={handleBuyStock} />;
      case 'contracts': return <SmartContracts contracts={contracts} onCreateContract={handleCreateContract} onWithdraw={handleWithdrawContract} />;
      case 'goals': return <Goals goals={goals} balance={user.balance} onAddGoal={handleAddGoal} onContribute={handleContributeToGoal} />;
      case 'education': return <Education transactions={transactions} user={user} lang={lang} />;
      case 'identity': return <Identity user={user} />;
      default: return null;
    }
  };

  if (!isAuthenticated) {
      return <Login onLogin={handleLogin} />;
  }

  // --- ADMIN VIEW ---
  if (isAdmin) {
      return <AdminDashboard onLogout={handleLogout} />;
  }

  if (user.isWalletLocked) {
      return (
          <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-6 text-center text-white">
              <div className="bg-red-500/20 p-6 rounded-full mb-6 animate-pulse">
                  <Lock size={64} className="text-red-500" />
              </div>
              <h1 className="text-3xl font-bold mb-2">Wallet Locked</h1>
              
              {!isRecovering ? (
                  <>
                    <p className="text-slate-400 max-w-md mb-8">
                        Your wallet has been locked by the server due to suspicious activity or multiple failed PIN attempts.
                    </p>
                    <div className="flex space-x-4">
                        <button onClick={fetchUserData} className="bg-slate-700 text-white px-6 py-3 rounded-xl font-bold hover:bg-slate-600 transition-colors">
                            Refresh Status
                        </button>
                        <button onClick={() => setIsRecovering(true)} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors flex items-center">
                            <KeyRound size={18} className="mr-2" />
                            Unlock Account
                        </button>
                    </div>
                  </>
              ) : (
                  <div className="bg-slate-800 p-8 rounded-2xl w-full max-w-md animate-fade-in border border-slate-700">
                      <h2 className="text-xl font-bold mb-4 flex items-center justify-center">
                          <Fingerprint className="mr-2 text-indigo-400" />
                          Verify Identity
                      </h2>
                      <div className="space-y-4 text-left">
                          <div>
                              <label className="block text-xs font-medium text-slate-400 mb-1">Registered Email</label>
                              <input 
                                type="email" 
                                value={recoveryEmail} 
                                onChange={e => setRecoveryEmail(e.target.value)}
                                className="w-full p-3 bg-slate-900 border border-slate-600 rounded-xl text-white outline-none focus:border-indigo-500"
                                placeholder="Enter your email"
                              />
                          </div>
                          <div>
                              <label className="block text-xs font-medium text-slate-400 mb-1">OTP (Simulated: 123456)</label>
                              <input 
                                type="text" 
                                value={recoveryOtp} 
                                onChange={e => setRecoveryOtp(e.target.value)}
                                className="w-full p-3 bg-slate-900 border border-slate-600 rounded-xl text-white outline-none focus:border-indigo-500 tracking-widest text-center font-bold text-lg"
                                placeholder="------"
                              />
                          </div>
                          <div className="flex space-x-3 mt-4">
                              <button onClick={() => setIsRecovering(false)} className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl font-medium">Cancel</button>
                              <button onClick={handleRecoverySubmit} className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 rounded-xl font-medium flex items-center justify-center">
                                  Verify & Unlock <ArrowRight size={16} className="ml-1" />
                              </button>
                          </div>
                      </div>
                  </div>
              )}
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex font-sans text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      <PinModal 
        isOpen={pinState.isOpen} 
        onClose={() => setPinState(prev => ({ ...prev, isOpen: false }))}
        onSubmit={handlePinSubmit}
        attempts={pinState.attempts}
      />

      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-20 md:hidden" onClick={() => setSidebarOpen(false)}></div>}

      <aside className={`fixed md:static inset-y-0 left-0 z-30 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transform transition-transform duration-200 ease-in-out ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 flex flex-col`}>
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
                <WalletIcon className="text-white w-5 h-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-800 dark:text-white">Credify</span>
          </div>
        </div>
        
        <nav className="p-4 space-y-1 flex-1 overflow-y-auto no-scrollbar">
          {NAV_KEYS.map((item) => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group
                ${activeTab === item.id 
                  ? 'bg-indigo-50 dark:bg-slate-800 text-indigo-700 dark:text-indigo-400 font-medium shadow-sm' 
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'}
              `}
            >
              <item.icon size={20} className={activeTab === item.id ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-300'} />
              <span>{t(lang, item.id as any)}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
             <button onClick={handleLogout} className="w-full flex items-center space-x-2 text-xs text-red-400 hover:text-red-600 px-4 py-2 transition-colors">
                 <LogOut size={14} />
                 <span>Logout</span>
             </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 h-16 flex items-center justify-between px-6 sticky top-0 z-10 transition-colors duration-200">
            <button className="md:hidden text-slate-500 dark:text-slate-400" onClick={() => setSidebarOpen(true)}>
                <Menu size={24} />
            </button>
            <h1 className="text-lg font-semibold text-slate-800 dark:text-white md:ml-0 ml-4 hidden md:block">
                {t(lang, activeTab as any)}
            </h1>
            <div className="flex items-center space-x-4">
                 <button 
                    onClick={() => setLang(lang === 'en' ? 'hi' : 'en')}
                    className="flex items-center space-x-1 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                 >
                     <Languages size={16} />
                     <span>{lang === 'en' ? 'English' : 'हिंदी'}</span>
                 </button>
                 
                 <button 
                    onClick={() => setDarkMode(!darkMode)}
                    className="p-2 text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-full transition-colors"
                 >
                     {darkMode ? <Sun size={20} className="text-yellow-400" /> : <Moon size={20} />}
                 </button>

                 <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-700 dark:text-indigo-300 font-bold text-sm border-2 border-white dark:border-slate-700 shadow-sm">
                     {user.name.charAt(0)}
                 </div>
            </div>
        </header>

        <div className="flex-1 overflow-auto p-4 md:p-8">
            <div className="max-w-6xl mx-auto">
                {renderContent()}
            </div>
        </div>
      </main>
    </div>
  );
}

export default App;
