
export enum TransactionType {
  EXPENSE = 'EXPENSE',
  INCOME = 'INCOME',
  TRANSFER = 'TRANSFER',
  SAVINGS = 'SAVINGS', // Deprecated
  CONTRACT_LOCK = 'CONTRACT_LOCK',
  CONTRACT_UNLOCK = 'CONTRACT_UNLOCK',
  INVESTMENT = 'INVESTMENT'
}

export enum Category {
  FOOD = 'Food',
  EDUCATION = 'Education',
  TRAVEL = 'Travel',
  BILLS = 'Bills',
  HEALTH = 'Health',
  ENTERTAINMENT = 'Entertainment',
  FAMILY = 'Family Support',
  OTHER = 'Other',
  SAVINGS = 'Savings', // Deprecated
  CONTRACT = 'Smart Contract',
  INVESTMENT = 'Investment'
}

export interface Transaction {
  id: string; // MongoDB _id
  amount: number;
  category: Category | string;
  description: string;
  date: string; // ISO String
  type: TransactionType;
  hash?: string; // Blockchain hash
  isSuspicious?: boolean;
  fraudReason?: string; // New: Reason for flagging
  location?: string; // New: Geo-tagging
  isVerified?: boolean; // Proof-of-Spend
  status?: 'SUCCESS' | 'FAILED' | 'FLAGGED';
  currency?: 'INR' | 'SRC'; // Added currency support
}

export interface TransactionRequest {
  amount: number;
  category: string;
  description: string;
  type: TransactionType;
  location?: string; // Optional simulation of geo-data
  receiver?: string;
  currency?: 'INR' | 'SRC'; // Added currency support
}

export interface FraudAnalysis {
  isFraud: boolean;
  reasons: string[];
  riskScore: number; // 0-100
}

export interface Block {
  index: number;
  timestamp: string;
  data: Transaction;
  previousHash: string;
  hash: string;
  encryptedData?: string; // For security demo
}

export interface PortfolioItem {
  symbol: string;
  name: string;
  quantity: number;
  avgPrice: number;
}

export interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number; // Percentage change
  isUp: boolean;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  ifsc: string;
  isPrimary: boolean;
}

export interface PinState {
  isOpen: boolean;
  attempts: number;
  isLocked: boolean;
  lockUntil: number | null; // Timestamp
}

export interface UserProfile {
  id?: string;
  name: string;
  email?: string;
  did: string; // Decentralized ID
  balance: number;
  lockedBalance: number; // Smart Contract Locked
  tokenBalance: number; // SecureCoin (SRC)
  currency: string;
  language: 'en' | 'hi';
  budgetLimit: number;
  trustScore: number;
  portfolio: PortfolioItem[];
  linkedBanks: BankAccount[];
  isWalletLocked: boolean;
  isAdmin?: boolean; // New field for Admin Check
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  color: string;
}

export interface Bill {
  id: string;
  name: string;
  amount: number;
  dueDate: string;
  isPaid: boolean;
}

export enum ContractType {
  TIME_LOCK = 'TIME_LOCK',
  EMERGENCY_FUND = 'EMERGENCY_FUND'
}

export interface SmartContract {
  id: string;
  type: ContractType;
  name: string;
  amount: number;
  creationDate: string;
  unlockDate?: string; // For Time Lock
  status: 'ACTIVE' | 'EXECUTED' | 'BROKEN';
  hash: string;
}

export type Language = 'en' | 'hi';

export interface Contact {
  id: string;
  name: string;
  mobile: string;
  avatar: string;
  trustScore: number;
}

export interface AdminStats {
  totalUsers: number;
  totalLiquidity: number;
  totalTransactions: number;
  flaggedTransactions: number;
}
